﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace NPOL.Report
{
    public partial class Xtra_EmpKPI_SubKPIInfo : DevExpress.XtraReports.UI.XtraReport
    {
        public Xtra_EmpKPI_SubKPIInfo()
        {
            InitializeComponent();
        }

    }
}
