﻿namespace NPOL.Report
{
    partial class Xtra_PersonnelRequisition_Full
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Xtra_PersonnelRequisition_Full));
            DevExpress.DataAccess.Sql.StoredProcQuery storedProcQuery1 = new DevExpress.DataAccess.Sql.StoredProcQuery();
            DevExpress.DataAccess.Sql.QueryParameter queryParameter1 = new DevExpress.DataAccess.Sql.QueryParameter();
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.xrPictureBox1 = new DevExpress.XtraReports.UI.XRPictureBox();
            this.xrLabel1 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel2 = new DevExpress.XtraReports.UI.XRLabel();
            this.TopMargin = new DevExpress.XtraReports.UI.TopMarginBand();
            this.BottomMargin = new DevExpress.XtraReports.UI.BottomMarginBand();
            this.DetailReport = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail1 = new DevExpress.XtraReports.UI.DetailBand();
            this.xrTable1 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow1 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell1 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell3 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel33 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableCell4 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableRow2 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell7 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell9 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel34 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableCell10 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell12 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel35 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableRow3 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell13 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell15 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel36 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableCell17 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell20 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel37 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableRow4 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell21 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell22 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel38 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableCell25 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel39 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableRow5 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell27 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell30 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox14 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.formattingRule2 = new DevExpress.XtraReports.UI.FormattingRule();
            this.xrTableCell31 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox20 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.formattingRule1 = new DevExpress.XtraReports.UI.FormattingRule();
            this.xrTableCell34 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableRow6 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell36 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell40 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox26 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell42 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox27 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell26 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox28 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell16 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox29 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell63 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox30 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell62 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox31 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableRow7 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell65 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell66 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox32 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell69 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel40 = new DevExpress.XtraReports.UI.XRLabel();
            this.sqlDataSource1 = new DevExpress.DataAccess.Sql.SqlDataSource(this.components);
            this.DetailReport1 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail2 = new DevExpress.XtraReports.UI.DetailBand();
            this.xrTable2 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow9 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell18 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell24 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell71 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableRow16 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell59 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell60 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell61 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell156 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell157 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell158 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableRow10 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell72 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell73 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox5 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell74 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox6 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell75 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox7 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell76 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox8 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell77 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableRow11 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell78 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell80 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox3 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell83 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox4 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableRow18 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell84 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell85 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox9 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell86 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox10 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell87 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox11 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell88 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox12 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell89 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox13 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrLabel4 = new DevExpress.XtraReports.UI.XRLabel();
            this.RequestID = new DevExpress.XtraReports.Parameters.Parameter();
            this.DetailReport2 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail3 = new DevExpress.XtraReports.UI.DetailBand();
            this.xrTable4 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow19 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell90 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell91 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel18 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableCell95 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel17 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel6 = new DevExpress.XtraReports.UI.XRLabel();
            this.GroupHeader1 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.DetailReport3 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail4 = new DevExpress.XtraReports.UI.DetailBand();
            this.xrTable5 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow32 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell139 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell141 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel5 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableCell143 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel7 = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport4 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail5 = new DevExpress.XtraReports.UI.DetailBand();
            this.xrTable6 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow23 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell115 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox21 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell117 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox22 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableCell119 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrCheckBox23 = new DevExpress.XtraReports.UI.XRCheckBox();
            this.xrTableRow20 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell32 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell35 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell38 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel3 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableRow26 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell135 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell137 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel10 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel8 = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport5 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail6 = new DevExpress.XtraReports.UI.DetailBand();
            this.xrTable3 = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow12 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell19 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell33 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell37 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableRow14 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell48 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell50 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel11 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableCell52 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel14 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableRow15 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell54 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell56 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel12 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableCell58 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel15 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableRow13 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell2 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell6 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel13 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableCell11 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel16 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableRow17 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell23 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell28 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel29 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableCell29 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel30 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableRow8 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell5 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell8 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel31 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrTableCell14 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrLabel32 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel9 = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport6 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail7 = new DevExpress.XtraReports.UI.DetailBand();
            this.xrLabel28 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel27 = new DevExpress.XtraReports.UI.XRLabel();
            this.DetailReport7 = new DevExpress.XtraReports.UI.DetailReportBand();
            this.Detail8 = new DevExpress.XtraReports.UI.DetailBand();
            this.chkGender_Male = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkGender_FeMale = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkPaygroup_ZPV = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkPaygroup_ZPS = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkPaygroup_SANG = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkPaygroup_Casual = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkPaygroup_Other = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkNewHeadcount_1 = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkNewHeadcount_2 = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkNewHeadcount_3 = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkNewHeadcount_4 = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkReplacement_1 = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkReplacement_2 = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkReplacement_3 = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkReplacement_4 = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkReplacement_5 = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkWorking = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkResigned = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkProbation_None = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkProbation_30 = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkProbation_60 = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkPaygroup_OtherName = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkIn_Budget = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkOut_Budget = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkPaygroup_PHYTO = new DevExpress.XtraReports.UI.CalculatedField();
            this.chkPaygroup_METRO = new DevExpress.XtraReports.UI.CalculatedField();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // Detail
            // 
            this.Detail.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrPictureBox1,
            this.xrLabel1,
            this.xrLabel2});
            this.Detail.HeightF = 113.625F;
            this.Detail.Name = "Detail";
            this.Detail.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.Detail.PageBreak = DevExpress.XtraReports.UI.PageBreak.BeforeBand;
            this.Detail.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrPictureBox1
            // 
            this.xrPictureBox1.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Bookmark", null, "spKPI_GetTable_rptEmpKPI.EmployeeName")});
            this.xrPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("xrPictureBox1.Image")));
            this.xrPictureBox1.LocationFloat = new DevExpress.Utils.PointFloat(330.455F, 0F);
            this.xrPictureBox1.Name = "xrPictureBox1";
            this.xrPictureBox1.SizeF = new System.Drawing.SizeF(171.545F, 35.5F);
            this.xrPictureBox1.Sizing = DevExpress.XtraPrinting.ImageSizeMode.ZoomImage;
            // 
            // xrLabel1
            // 
            this.xrLabel1.Font = new System.Drawing.Font("Times New Roman", 13F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.xrLabel1.LocationFloat = new DevExpress.Utils.PointFloat(150.7675F, 49.04168F);
            this.xrLabel1.Multiline = true;
            this.xrLabel1.Name = "xrLabel1";
            this.xrLabel1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel1.SizeF = new System.Drawing.SizeF(550F, 27.08334F);
            this.xrLabel1.StylePriority.UseFont = false;
            this.xrLabel1.StylePriority.UseTextAlignment = false;
            this.xrLabel1.Text = "PERSONNEL REQUISITION FORM";
            this.xrLabel1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // xrLabel2
            // 
            this.xrLabel2.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.xrLabel2.LocationFloat = new DevExpress.Utils.PointFloat(150.7675F, 76.12502F);
            this.xrLabel2.Multiline = true;
            this.xrLabel2.Name = "xrLabel2";
            this.xrLabel2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel2.SizeF = new System.Drawing.SizeF(550F, 37.5F);
            this.xrLabel2.StylePriority.UseFont = false;
            this.xrLabel2.StylePriority.UseTextAlignment = false;
            this.xrLabel2.Text = "BẢN YÊU CẦU TUYỂN DỤNG";
            this.xrLabel2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // TopMargin
            // 
            this.TopMargin.HeightF = 50F;
            this.TopMargin.Name = "TopMargin";
            this.TopMargin.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.TopMargin.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // BottomMargin
            // 
            this.BottomMargin.HeightF = 50F;
            this.BottomMargin.Name = "BottomMargin";
            this.BottomMargin.Padding = new DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100F);
            this.BottomMargin.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // DetailReport
            // 
            this.DetailReport.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail1});
            this.DetailReport.DataSource = this.sqlDataSource1;
            this.DetailReport.Level = 0;
            this.DetailReport.Name = "DetailReport";
            // 
            // Detail1
            // 
            this.Detail1.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable1});
            this.Detail1.HeightF = 196.6084F;
            this.Detail1.Name = "Detail1";
            this.Detail1.StylePriority.UseBorders = false;
            // 
            // xrTable1
            // 
            this.xrTable1.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTable1.Font = new System.Drawing.Font("Times New Roman", 8.5F);
            this.xrTable1.LocationFloat = new DevExpress.Utils.PointFloat(10.00013F, 0F);
            this.xrTable1.Name = "xrTable1";
            this.xrTable1.Padding = new DevExpress.XtraPrinting.PaddingInfo(5, 5, 5, 5, 100F);
            this.xrTable1.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow1,
            this.xrTableRow2,
            this.xrTableRow3,
            this.xrTableRow4,
            this.xrTableRow5,
            this.xrTableRow6,
            this.xrTableRow7});
            this.xrTable1.SizeF = new System.Drawing.SizeF(800F, 185.84F);
            this.xrTable1.StylePriority.UseBackColor = false;
            this.xrTable1.StylePriority.UseBorders = false;
            this.xrTable1.StylePriority.UseFont = false;
            this.xrTable1.StylePriority.UsePadding = false;
            // 
            // xrTableRow1
            // 
            this.xrTableRow1.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell1,
            this.xrTableCell3,
            this.xrTableCell4});
            this.xrTableRow1.Name = "xrTableRow1";
            this.xrTableRow1.Weight = 0.855440261550685D;
            // 
            // xrTableCell1
            // 
            this.xrTableCell1.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell1.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell1.BorderWidth = 1F;
            this.xrTableCell1.Name = "xrTableCell1";
            this.xrTableCell1.StylePriority.UseBorderColor = false;
            this.xrTableCell1.StylePriority.UseBorders = false;
            this.xrTableCell1.StylePriority.UseBorderWidth = false;
            this.xrTableCell1.Text = "Full name / Họ tên nhân viên: ";
            this.xrTableCell1.Weight = 1.0638055224072556D;
            // 
            // xrTableCell3
            // 
            this.xrTableCell3.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell3.Borders = DevExpress.XtraPrinting.BorderSide.Top;
            this.xrTableCell3.BorderWidth = 1F;
            this.xrTableCell3.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel33});
            this.xrTableCell3.Name = "xrTableCell3";
            this.xrTableCell3.StylePriority.UseBorderColor = false;
            this.xrTableCell3.StylePriority.UseBorders = false;
            this.xrTableCell3.StylePriority.UseBorderWidth = false;
            this.xrTableCell3.Weight = 1.4754584698369813D;
            // 
            // xrLabel33
            // 
            this.xrLabel33.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel33.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Apply_Name")});
            this.xrLabel33.LocationFloat = new DevExpress.Utils.PointFloat(11.41999F, 2.000003F);
            this.xrLabel33.Name = "xrLabel33";
            this.xrLabel33.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 2, 0, 100F);
            this.xrLabel33.SizeF = new System.Drawing.SizeF(220.1796F, 22F);
            this.xrLabel33.StylePriority.UseBorders = false;
            this.xrLabel33.StylePriority.UsePadding = false;
            // 
            // xrTableCell4
            // 
            this.xrTableCell4.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell4.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Right)));
            this.xrTableCell4.BorderWidth = 1F;
            this.xrTableCell4.Name = "xrTableCell4";
            this.xrTableCell4.StylePriority.UseBorderColor = false;
            this.xrTableCell4.StylePriority.UseBorders = false;
            this.xrTableCell4.StylePriority.UseBorderWidth = false;
            this.xrTableCell4.Weight = 2.3463693997078634D;
            // 
            // xrTableRow2
            // 
            this.xrTableRow2.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell7,
            this.xrTableCell9,
            this.xrTableCell10,
            this.xrTableCell12});
            this.xrTableRow2.Name = "xrTableRow2";
            this.xrTableRow2.Weight = 0.85544026155068509D;
            // 
            // xrTableCell7
            // 
            this.xrTableCell7.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell7.Borders = DevExpress.XtraPrinting.BorderSide.Left;
            this.xrTableCell7.BorderWidth = 1F;
            this.xrTableCell7.Name = "xrTableCell7";
            this.xrTableCell7.StylePriority.UseBorderColor = false;
            this.xrTableCell7.StylePriority.UseBorders = false;
            this.xrTableCell7.StylePriority.UseBorderWidth = false;
            this.xrTableCell7.Text = "Department/ Phòng ban: ";
            this.xrTableCell7.Weight = 1.4184071602099444D;
            // 
            // xrTableCell9
            // 
            this.xrTableCell9.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel34});
            this.xrTableCell9.Name = "xrTableCell9";
            this.xrTableCell9.Weight = 1.9672782976667134D;
            // 
            // xrLabel34
            // 
            this.xrLabel34.BorderColor = System.Drawing.Color.DarkGray;
            this.xrLabel34.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel34.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.LineID")});
            this.xrLabel34.LocationFloat = new DevExpress.Utils.PointFloat(11.31263F, 0F);
            this.xrLabel34.Name = "xrLabel34";
            this.xrLabel34.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel34.SizeF = new System.Drawing.SizeF(220.1796F, 22F);
            this.xrLabel34.StylePriority.UseBorderColor = false;
            this.xrLabel34.StylePriority.UseBorders = false;
            // 
            // xrTableCell10
            // 
            this.xrTableCell10.Name = "xrTableCell10";
            this.xrTableCell10.Text = "Title / Chức vụ: ";
            this.xrTableCell10.Weight = 1.0518834519998963D;
            // 
            // xrTableCell12
            // 
            this.xrTableCell12.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell12.Borders = DevExpress.XtraPrinting.BorderSide.Right;
            this.xrTableCell12.BorderWidth = 1F;
            this.xrTableCell12.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel35});
            this.xrTableCell12.Name = "xrTableCell12";
            this.xrTableCell12.StylePriority.UseBorderColor = false;
            this.xrTableCell12.StylePriority.UseBorders = false;
            this.xrTableCell12.StylePriority.UseBorderWidth = false;
            this.xrTableCell12.Weight = 2.0766089460595794D;
            // 
            // xrLabel35
            // 
            this.xrLabel35.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel35.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.PosID")});
            this.xrLabel35.LocationFloat = new DevExpress.Utils.PointFloat(6.046925F, 0F);
            this.xrLabel35.Name = "xrLabel35";
            this.xrLabel35.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel35.SizeF = new System.Drawing.SizeF(238.9794F, 22F);
            this.xrLabel35.StylePriority.UseBorders = false;
            // 
            // xrTableRow3
            // 
            this.xrTableRow3.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell13,
            this.xrTableCell15,
            this.xrTableCell17,
            this.xrTableCell20});
            this.xrTableRow3.Name = "xrTableRow3";
            this.xrTableRow3.Weight = 0.85544026155068487D;
            // 
            // xrTableCell13
            // 
            this.xrTableCell13.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell13.Borders = DevExpress.XtraPrinting.BorderSide.Left;
            this.xrTableCell13.BorderWidth = 1F;
            this.xrTableCell13.Name = "xrTableCell13";
            this.xrTableCell13.StylePriority.UseBorderColor = false;
            this.xrTableCell13.StylePriority.UseBorders = false;
            this.xrTableCell13.StylePriority.UseBorderWidth = false;
            this.xrTableCell13.Text = "Division / Bộ phận: ";
            this.xrTableCell13.Weight = 1.4184071602099444D;
            // 
            // xrTableCell15
            // 
            this.xrTableCell15.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel36});
            this.xrTableCell15.Name = "xrTableCell15";
            this.xrTableCell15.Weight = 1.9672780278980304D;
            // 
            // xrLabel36
            // 
            this.xrLabel36.BorderColor = System.Drawing.Color.DarkGray;
            this.xrLabel36.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel36.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.DepID")});
            this.xrLabel36.LocationFloat = new DevExpress.Utils.PointFloat(11.31263F, 2.288818E-05F);
            this.xrLabel36.Name = "xrLabel36";
            this.xrLabel36.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel36.SizeF = new System.Drawing.SizeF(220.1796F, 22F);
            this.xrLabel36.StylePriority.UseBorderColor = false;
            this.xrLabel36.StylePriority.UseBorders = false;
            // 
            // xrTableCell17
            // 
            this.xrTableCell17.Name = "xrTableCell17";
            this.xrTableCell17.Text = "Working location/ Địa điểm làm việc: ";
            this.xrTableCell17.Weight = 1.0518839945514562D;
            // 
            // xrTableCell20
            // 
            this.xrTableCell20.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell20.Borders = DevExpress.XtraPrinting.BorderSide.Right;
            this.xrTableCell20.BorderWidth = 1F;
            this.xrTableCell20.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel37});
            this.xrTableCell20.Name = "xrTableCell20";
            this.xrTableCell20.StylePriority.UseBorderColor = false;
            this.xrTableCell20.StylePriority.UseBorders = false;
            this.xrTableCell20.StylePriority.UseBorderWidth = false;
            this.xrTableCell20.Weight = 2.0766086732767022D;
            // 
            // xrLabel37
            // 
            this.xrLabel37.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel37.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.LocationID")});
            this.xrLabel37.LocationFloat = new DevExpress.Utils.PointFloat(6.046925F, 0F);
            this.xrLabel37.Name = "xrLabel37";
            this.xrLabel37.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel37.SizeF = new System.Drawing.SizeF(238.9794F, 22F);
            this.xrLabel37.StylePriority.UseBorders = false;
            // 
            // xrTableRow4
            // 
            this.xrTableRow4.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell21,
            this.xrTableCell22,
            this.xrTableCell25});
            this.xrTableRow4.Name = "xrTableRow4";
            this.xrTableRow4.Weight = 0.855440261550685D;
            // 
            // xrTableCell21
            // 
            this.xrTableCell21.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell21.Borders = DevExpress.XtraPrinting.BorderSide.Left;
            this.xrTableCell21.BorderWidth = 1F;
            this.xrTableCell21.Name = "xrTableCell21";
            this.xrTableCell21.StylePriority.UseBorderColor = false;
            this.xrTableCell21.StylePriority.UseBorders = false;
            this.xrTableCell21.StylePriority.UseBorderWidth = false;
            this.xrTableCell21.Text = "Report to / Báo cáo đến: ";
            this.xrTableCell21.Weight = 1.0638055468503302D;
            // 
            // xrTableCell22
            // 
            this.xrTableCell22.BorderColor = System.Drawing.Color.Silver;
            this.xrTableCell22.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell22.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel38});
            this.xrTableCell22.Name = "xrTableCell22";
            this.xrTableCell22.StylePriority.UseBorderColor = false;
            this.xrTableCell22.StylePriority.UseBorders = false;
            this.xrTableCell22.Weight = 0.82629212587907053D;
            // 
            // xrLabel38
            // 
            this.xrLabel38.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel38.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.ReportTo")});
            this.xrLabel38.LocationFloat = new DevExpress.Utils.PointFloat(11.31568F, 0F);
            this.xrLabel38.Name = "xrLabel38";
            this.xrLabel38.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 2, 0, 100F);
            this.xrLabel38.SizeF = new System.Drawing.SizeF(123.9859F, 22F);
            this.xrLabel38.StylePriority.UseBorders = false;
            this.xrLabel38.StylePriority.UsePadding = false;
            // 
            // xrTableCell25
            // 
            this.xrTableCell25.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell25.Borders = DevExpress.XtraPrinting.BorderSide.Right;
            this.xrTableCell25.BorderWidth = 1F;
            this.xrTableCell25.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel39});
            this.xrTableCell25.Name = "xrTableCell25";
            this.xrTableCell25.StylePriority.UseBorderColor = false;
            this.xrTableCell25.StylePriority.UseBorders = false;
            this.xrTableCell25.StylePriority.UseBorderWidth = false;
            this.xrTableCell25.Weight = 2.9955357192226995D;
            // 
            // xrLabel39
            // 
            this.xrLabel39.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel39.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.ReportTo_Name")});
            this.xrLabel39.LocationFloat = new DevExpress.Utils.PointFloat(6.833912F, 0F);
            this.xrLabel39.Name = "xrLabel39";
            this.xrLabel39.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 2, 0, 100F);
            this.xrLabel39.SizeF = new System.Drawing.SizeF(473.6713F, 22F);
            this.xrLabel39.StylePriority.UseBorders = false;
            this.xrLabel39.StylePriority.UsePadding = false;
            // 
            // xrTableRow5
            // 
            this.xrTableRow5.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell27,
            this.xrTableCell30,
            this.xrTableCell31,
            this.xrTableCell34});
            this.xrTableRow5.Name = "xrTableRow5";
            this.xrTableRow5.Weight = 0.92672694839456859D;
            // 
            // xrTableCell27
            // 
            this.xrTableCell27.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell27.Borders = DevExpress.XtraPrinting.BorderSide.Left;
            this.xrTableCell27.BorderWidth = 1F;
            this.xrTableCell27.Name = "xrTableCell27";
            this.xrTableCell27.StylePriority.UseBorderColor = false;
            this.xrTableCell27.StylePriority.UseBorders = false;
            this.xrTableCell27.StylePriority.UseBorderWidth = false;
            this.xrTableCell27.Text = "Gender/ Giới tính:";
            this.xrTableCell27.Weight = 1.4184071602099444D;
            // 
            // xrTableCell30
            // 
            this.xrTableCell30.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox14});
            this.xrTableCell30.Multiline = true;
            this.xrTableCell30.Name = "xrTableCell30";
            this.xrTableCell30.Weight = 1.1017231072883043D;
            // 
            // xrCheckBox14
            // 
            this.xrCheckBox14.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkGender_Male")});
            this.xrCheckBox14.FormattingRules.Add(this.formattingRule2);
            this.xrCheckBox14.LocationFloat = new DevExpress.Utils.PointFloat(11.41523F, 0F);
            this.xrCheckBox14.Name = "xrCheckBox14";
            this.xrCheckBox14.SizeF = new System.Drawing.SizeF(101.84F, 23F);
            this.xrCheckBox14.Text = "Male / Nam";
            // 
            // formattingRule2
            // 
            this.formattingRule2.Condition = "Iif( [SexID] = \'F\', false, true)";
            this.formattingRule2.Name = "formattingRule2";
            // 
            // xrTableCell31
            // 
            this.xrTableCell31.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox20});
            this.xrTableCell31.Multiline = true;
            this.xrTableCell31.Name = "xrTableCell31";
            this.xrTableCell31.Weight = 3.0047318166347794D;
            // 
            // xrCheckBox20
            // 
            this.xrCheckBox20.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkGender_FeMale")});
            this.xrCheckBox20.FormattingRules.Add(this.formattingRule1);
            this.xrCheckBox20.LocationFloat = new DevExpress.Utils.PointFloat(6.833935F, 0F);
            this.xrCheckBox20.Name = "xrCheckBox20";
            this.xrCheckBox20.SizeF = new System.Drawing.SizeF(100F, 23F);
            this.xrCheckBox20.Text = "Female / Nữ";
            // 
            // formattingRule1
            // 
            this.formattingRule1.Condition = "Iif( [SexID] = \'F\', true, false)";
            this.formattingRule1.Name = "formattingRule1";
            // 
            // xrTableCell34
            // 
            this.xrTableCell34.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell34.Borders = DevExpress.XtraPrinting.BorderSide.Right;
            this.xrTableCell34.BorderWidth = 1F;
            this.xrTableCell34.Name = "xrTableCell34";
            this.xrTableCell34.StylePriority.UseBorderColor = false;
            this.xrTableCell34.StylePriority.UseBorders = false;
            this.xrTableCell34.StylePriority.UseBorderWidth = false;
            this.xrTableCell34.Weight = 0.98931577180310493D;
            // 
            // xrTableRow6
            // 
            this.xrTableRow6.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell36,
            this.xrTableCell40,
            this.xrTableCell42,
            this.xrTableCell26,
            this.xrTableCell16,
            this.xrTableCell63,
            this.xrTableCell62});
            this.xrTableRow6.Name = "xrTableRow6";
            this.xrTableRow6.Weight = 0.92672694839456859D;
            // 
            // xrTableCell36
            // 
            this.xrTableCell36.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell36.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell36.BorderWidth = 1F;
            this.xrTableCell36.Name = "xrTableCell36";
            this.xrTableCell36.RowSpan = 2;
            this.xrTableCell36.StylePriority.UseBorderColor = false;
            this.xrTableCell36.StylePriority.UseBorders = false;
            this.xrTableCell36.StylePriority.UseBorderWidth = false;
            this.xrTableCell36.Text = "Employee Payroll Group / Nhóm:";
            this.xrTableCell36.Weight = 1.5862144506607894D;
            // 
            // xrTableCell40
            // 
            this.xrTableCell40.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox26});
            this.xrTableCell40.Name = "xrTableCell40";
            this.xrTableCell40.Weight = 1.2320643903614237D;
            // 
            // xrCheckBox26
            // 
            this.xrCheckBox26.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkPaygroup_ZPV")});
            this.xrCheckBox26.LocationFloat = new DevExpress.Utils.PointFloat(11.41521F, 0F);
            this.xrCheckBox26.Name = "xrCheckBox26";
            this.xrCheckBox26.SizeF = new System.Drawing.SizeF(101.8431F, 23F);
            this.xrCheckBox26.Text = " ZPV";
            // 
            // xrTableCell42
            // 
            this.xrTableCell42.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox27});
            this.xrTableCell42.Name = "xrTableCell42";
            this.xrTableCell42.Weight = 0.71185435085911464D;
            // 
            // xrCheckBox27
            // 
            this.xrCheckBox27.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkPaygroup_ZPS")});
            this.xrCheckBox27.LocationFloat = new DevExpress.Utils.PointFloat(6.833916F, 0F);
            this.xrCheckBox27.Name = "xrCheckBox27";
            this.xrCheckBox27.SizeF = new System.Drawing.SizeF(64.37503F, 23F);
            this.xrCheckBox27.Text = "  ZPS";
            // 
            // xrTableCell26
            // 
            this.xrTableCell26.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox28});
            this.xrTableCell26.Name = "xrTableCell26";
            this.xrTableCell26.Weight = 0.72597529423119045D;
            // 
            // xrCheckBox28
            // 
            this.xrCheckBox28.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkPaygroup_SANG")});
            this.xrCheckBox28.LocationFloat = new DevExpress.Utils.PointFloat(8.784569F, 0F);
            this.xrCheckBox28.Name = "xrCheckBox28";
            this.xrCheckBox28.SizeF = new System.Drawing.SizeF(68.75601F, 23F);
            this.xrCheckBox28.Text = "SANG";
            // 
            // xrTableCell16
            // 
            this.xrTableCell16.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox29});
            this.xrTableCell16.Name = "xrTableCell16";
            this.xrTableCell16.Weight = 0.70645541640729737D;
            // 
            // xrCheckBox29
            // 
            this.xrCheckBox29.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkPaygroup_PHYTO")});
            this.xrCheckBox29.LocationFloat = new DevExpress.Utils.PointFloat(6.046928F, 0F);
            this.xrCheckBox29.Name = "xrCheckBox29";
            this.xrCheckBox29.SizeF = new System.Drawing.SizeF(70.83334F, 23F);
            this.xrCheckBox29.Text = "PHYTO";
            // 
            // xrTableCell63
            // 
            this.xrTableCell63.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox30});
            this.xrTableCell63.Name = "xrTableCell63";
            this.xrTableCell63.Text = "xrTableCell63";
            this.xrTableCell63.Weight = 1.215926635972886D;
            // 
            // xrCheckBox30
            // 
            this.xrCheckBox30.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkPaygroup_METRO")});
            this.xrCheckBox30.LocationFloat = new DevExpress.Utils.PointFloat(6.357829E-05F, 0F);
            this.xrCheckBox30.Name = "xrCheckBox30";
            this.xrCheckBox30.SizeF = new System.Drawing.SizeF(120.0091F, 23F);
            this.xrCheckBox30.Text = "METRO HEALTH";
            // 
            // xrTableCell62
            // 
            this.xrTableCell62.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell62.Borders = DevExpress.XtraPrinting.BorderSide.Right;
            this.xrTableCell62.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox31});
            this.xrTableCell62.Name = "xrTableCell62";
            this.xrTableCell62.StylePriority.UseBorderColor = false;
            this.xrTableCell62.StylePriority.UseBorders = false;
            this.xrTableCell62.Weight = 1.1063591882938164D;
            // 
            // xrCheckBox31
            // 
            this.xrCheckBox31.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox31.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkPaygroup_Casual")});
            this.xrCheckBox31.LocationFloat = new DevExpress.Utils.PointFloat(9.406059F, 0F);
            this.xrCheckBox31.Name = "xrCheckBox31";
            this.xrCheckBox31.SizeF = new System.Drawing.SizeF(69.7594F, 23F);
            this.xrCheckBox31.StylePriority.UseBorders = false;
            this.xrCheckBox31.Text = " Casual";
            // 
            // xrTableRow7
            // 
            this.xrTableRow7.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell65,
            this.xrTableCell66,
            this.xrTableCell69});
            this.xrTableRow7.Name = "xrTableRow7";
            this.xrTableRow7.Weight = 0.99801349926988769D;
            // 
            // xrTableCell65
            // 
            this.xrTableCell65.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell65.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrTableCell65.BorderWidth = 1F;
            this.xrTableCell65.Name = "xrTableCell65";
            this.xrTableCell65.StylePriority.UseBorderColor = false;
            this.xrTableCell65.StylePriority.UseBorders = false;
            this.xrTableCell65.StylePriority.UseBorderWidth = false;
            this.xrTableCell65.Weight = 1.0638053565770813D;
            // 
            // xrTableCell66
            // 
            this.xrTableCell66.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell66.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrTableCell66.BorderWidth = 1F;
            this.xrTableCell66.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox32});
            this.xrTableCell66.Name = "xrTableCell66";
            this.xrTableCell66.StylePriority.UseBorderColor = false;
            this.xrTableCell66.StylePriority.UseBorders = false;
            this.xrTableCell66.StylePriority.UseBorderWidth = false;
            this.xrTableCell66.Weight = 0.8262923304662283D;
            // 
            // xrCheckBox32
            // 
            this.xrCheckBox32.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox32.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkPaygroup_Other")});
            this.xrCheckBox32.LocationFloat = new DevExpress.Utils.PointFloat(11.31264F, 0F);
            this.xrCheckBox32.Name = "xrCheckBox32";
            this.xrCheckBox32.SizeF = new System.Drawing.SizeF(101.8431F, 23F);
            this.xrCheckBox32.StylePriority.UseBorders = false;
            this.xrCheckBox32.Text = " Other";
            // 
            // xrTableCell69
            // 
            this.xrTableCell69.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell69.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Right | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell69.BorderWidth = 1F;
            this.xrTableCell69.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel40});
            this.xrTableCell69.Name = "xrTableCell69";
            this.xrTableCell69.StylePriority.UseBorderColor = false;
            this.xrTableCell69.StylePriority.UseBorders = false;
            this.xrTableCell69.StylePriority.UseBorderWidth = false;
            this.xrTableCell69.Weight = 2.9955357049087903D;
            // 
            // xrLabel40
            // 
            this.xrLabel40.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel40.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.chkPaygroup_OtherName")});
            this.xrLabel40.LocationFloat = new DevExpress.Utils.PointFloat(8.060413F, 0F);
            this.xrLabel40.Name = "xrLabel40";
            this.xrLabel40.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 2, 0, 100F);
            this.xrLabel40.SizeF = new System.Drawing.SizeF(440.1132F, 22F);
            this.xrLabel40.StylePriority.UseBorders = false;
            this.xrLabel40.StylePriority.UsePadding = false;
            // 
            // sqlDataSource1
            // 
            this.sqlDataSource1.ConnectionName = "ZuelligConnection";
            this.sqlDataSource1.Name = "sqlDataSource1";
            storedProcQuery1.Name = "spRC_Print_PersonnelRequisition";
            queryParameter1.Name = "@RequestID";
            queryParameter1.Type = typeof(DevExpress.DataAccess.Expression);
            queryParameter1.Value = new DevExpress.DataAccess.Expression("[Parameters.RequestID]", typeof(string));
            storedProcQuery1.Parameters.Add(queryParameter1);
            storedProcQuery1.StoredProcName = "spRC_Print_PersonnelRequisition";
            this.sqlDataSource1.Queries.AddRange(new DevExpress.DataAccess.Sql.SqlQuery[] {
            storedProcQuery1});
            this.sqlDataSource1.ResultSchemaSerializable = resources.GetString("sqlDataSource1.ResultSchemaSerializable");
            // 
            // DetailReport1
            // 
            this.DetailReport1.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail2});
            this.DetailReport1.DataSource = this.sqlDataSource1;
            this.DetailReport1.Level = 1;
            this.DetailReport1.Name = "DetailReport1";
            // 
            // Detail2
            // 
            this.Detail2.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable2,
            this.xrLabel4});
            this.Detail2.HeightF = 196.5012F;
            this.Detail2.Name = "Detail2";
            // 
            // xrTable2
            // 
            this.xrTable2.BorderColor = System.Drawing.Color.Gray;
            this.xrTable2.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTable2.Font = new System.Drawing.Font("Times New Roman", 8.5F);
            this.xrTable2.LocationFloat = new DevExpress.Utils.PointFloat(10.00013F, 27.73482F);
            this.xrTable2.Name = "xrTable2";
            this.xrTable2.Padding = new DevExpress.XtraPrinting.PaddingInfo(5, 5, 5, 5, 100F);
            this.xrTable2.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow9,
            this.xrTableRow16,
            this.xrTableRow10,
            this.xrTableRow11,
            this.xrTableRow18});
            this.xrTable2.SizeF = new System.Drawing.SizeF(800F, 160.85F);
            this.xrTable2.StylePriority.UseBackColor = false;
            this.xrTable2.StylePriority.UseBorderColor = false;
            this.xrTable2.StylePriority.UseBorders = false;
            this.xrTable2.StylePriority.UseFont = false;
            this.xrTable2.StylePriority.UsePadding = false;
            // 
            // xrTableRow9
            // 
            this.xrTableRow9.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell18,
            this.xrTableCell24,
            this.xrTableCell71});
            this.xrTableRow9.Name = "xrTableRow9";
            this.xrTableRow9.Weight = 1D;
            // 
            // xrTableCell18
            // 
            this.xrTableCell18.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell18.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell18.Name = "xrTableCell18";
            this.xrTableCell18.StylePriority.UseBorderColor = false;
            this.xrTableCell18.StylePriority.UseBorders = false;
            this.xrTableCell18.Weight = 0.6986182798067444D;
            // 
            // xrTableCell24
            // 
            this.xrTableCell24.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell24.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell24.Multiline = true;
            this.xrTableCell24.Name = "xrTableCell24";
            this.xrTableCell24.StylePriority.UseBorderColor = false;
            this.xrTableCell24.StylePriority.UseBorders = false;
            this.xrTableCell24.StylePriority.UseTextAlignment = false;
            this.xrTableCell24.Text = "ZPV/ SANG/ PHYTO/ METRO HEALTH Staff\r\nNhân viên ZPV/ SANG/ PHYTO/ METRO HEALTH";
            this.xrTableCell24.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            this.xrTableCell24.Weight = 2.563400976208015D;
            // 
            // xrTableCell71
            // 
            this.xrTableCell71.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell71.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Right) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell71.Name = "xrTableCell71";
            this.xrTableCell71.StylePriority.UseBorderColor = false;
            this.xrTableCell71.StylePriority.UseBorders = false;
            this.xrTableCell71.StylePriority.UseTextAlignment = false;
            this.xrTableCell71.Text = "Casual Staff / Nhân viên không thường xuyên";
            this.xrTableCell71.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            this.xrTableCell71.Weight = 2.7379807439852404D;
            // 
            // xrTableRow16
            // 
            this.xrTableRow16.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell59,
            this.xrTableCell60,
            this.xrTableCell61,
            this.xrTableCell156,
            this.xrTableCell157,
            this.xrTableCell158});
            this.xrTableRow16.Name = "xrTableRow16";
            this.xrTableRow16.Weight = 1.4852879403317696D;
            // 
            // xrTableCell59
            // 
            this.xrTableCell59.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell59.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell59.Name = "xrTableCell59";
            this.xrTableCell59.StylePriority.UseBorderColor = false;
            this.xrTableCell59.StylePriority.UseBorders = false;
            this.xrTableCell59.Weight = 0.6986182798067444D;
            // 
            // xrTableCell60
            // 
            this.xrTableCell60.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrTableCell60.Multiline = true;
            this.xrTableCell60.Name = "xrTableCell60";
            this.xrTableCell60.StylePriority.UseBorders = false;
            this.xrTableCell60.StylePriority.UseTextAlignment = false;
            this.xrTableCell60.Text = "Full time\r\nNhân viên toàn thời gian";
            this.xrTableCell60.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            this.xrTableCell60.Weight = 0.91546581969407681D;
            // 
            // xrTableCell61
            // 
            this.xrTableCell61.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrTableCell61.Multiline = true;
            this.xrTableCell61.Name = "xrTableCell61";
            this.xrTableCell61.StylePriority.UseBorders = false;
            this.xrTableCell61.StylePriority.UseTextAlignment = false;
            this.xrTableCell61.Text = "Upgrade from casual staff \r\nChuyển từ nhân viên không thường xuyên sang ZPV/ SANG" +
    "/ PHYTO/ METRO HEALTH";
            this.xrTableCell61.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            this.xrTableCell61.Weight = 1.6479351565139389D;
            // 
            // xrTableCell156
            // 
            this.xrTableCell156.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrTableCell156.Multiline = true;
            this.xrTableCell156.Name = "xrTableCell156";
            this.xrTableCell156.StylePriority.UseBorders = false;
            this.xrTableCell156.StylePriority.UseTextAlignment = false;
            this.xrTableCell156.Text = "Full time\r\nNhân viên toàn thời gian";
            this.xrTableCell156.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            this.xrTableCell156.Weight = 0.87029487076843881D;
            // 
            // xrTableCell157
            // 
            this.xrTableCell157.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrTableCell157.Multiline = true;
            this.xrTableCell157.Name = "xrTableCell157";
            this.xrTableCell157.StylePriority.UseBorders = false;
            this.xrTableCell157.StylePriority.UseTextAlignment = false;
            this.xrTableCell157.Text = "Seasonal\r\nNhân viên thời vụ";
            this.xrTableCell157.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            this.xrTableCell157.Weight = 0.78682740783042293D;
            // 
            // xrTableCell158
            // 
            this.xrTableCell158.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell158.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Right | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell158.Multiline = true;
            this.xrTableCell158.Name = "xrTableCell158";
            this.xrTableCell158.StylePriority.UseBorderColor = false;
            this.xrTableCell158.StylePriority.UseBorders = false;
            this.xrTableCell158.StylePriority.UseTextAlignment = false;
            this.xrTableCell158.Text = "Maternity replacement\r\nNhân viên thay thế thai sản";
            this.xrTableCell158.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            this.xrTableCell158.Weight = 1.0808584653863784D;
            // 
            // xrTableRow10
            // 
            this.xrTableRow10.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell72,
            this.xrTableCell73,
            this.xrTableCell74,
            this.xrTableCell75,
            this.xrTableCell76,
            this.xrTableCell77});
            this.xrTableRow10.Name = "xrTableRow10";
            this.xrTableRow10.Weight = 0.88497794237250527D;
            // 
            // xrTableCell72
            // 
            this.xrTableCell72.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell72.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Right) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell72.Multiline = true;
            this.xrTableCell72.Name = "xrTableCell72";
            this.xrTableCell72.RowSpan = 2;
            this.xrTableCell72.StylePriority.UseBorderColor = false;
            this.xrTableCell72.StylePriority.UseBorders = false;
            this.xrTableCell72.Text = "New headcount \r\nVị trí mới";
            this.xrTableCell72.Weight = 0.6986182798067444D;
            // 
            // xrTableCell73
            // 
            this.xrTableCell73.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox5});
            this.xrTableCell73.Name = "xrTableCell73";
            this.xrTableCell73.Weight = 0.91546581969407681D;
            // 
            // xrCheckBox5
            // 
            this.xrCheckBox5.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox5.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkNewHeadcount_1")});
            this.xrCheckBox5.LocationFloat = new DevExpress.Utils.PointFloat(36.5569F, 0F);
            this.xrCheckBox5.Name = "xrCheckBox5";
            this.xrCheckBox5.SizeF = new System.Drawing.SizeF(75.50519F, 23.00001F);
            this.xrCheckBox5.StylePriority.UseBorders = false;
            // 
            // xrTableCell74
            // 
            this.xrTableCell74.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox6});
            this.xrTableCell74.Name = "xrTableCell74";
            this.xrTableCell74.Weight = 1.6479351565139389D;
            // 
            // xrCheckBox6
            // 
            this.xrCheckBox6.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox6.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkNewHeadcount_2")});
            this.xrCheckBox6.LocationFloat = new DevExpress.Utils.PointFloat(74.23235F, 0F);
            this.xrCheckBox6.Name = "xrCheckBox6";
            this.xrCheckBox6.SizeF = new System.Drawing.SizeF(100F, 23F);
            this.xrCheckBox6.StylePriority.UseBorders = false;
            // 
            // xrTableCell75
            // 
            this.xrTableCell75.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox7});
            this.xrTableCell75.Name = "xrTableCell75";
            this.xrTableCell75.Weight = 0.87029487076843881D;
            // 
            // xrCheckBox7
            // 
            this.xrCheckBox7.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox7.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkNewHeadcount_3")});
            this.xrCheckBox7.LocationFloat = new DevExpress.Utils.PointFloat(15.9154F, 0F);
            this.xrCheckBox7.Name = "xrCheckBox7";
            this.xrCheckBox7.SizeF = new System.Drawing.SizeF(100F, 23F);
            this.xrCheckBox7.StylePriority.UseBorders = false;
            // 
            // xrTableCell76
            // 
            this.xrTableCell76.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox8});
            this.xrTableCell76.Name = "xrTableCell76";
            this.xrTableCell76.Weight = 0.78682740783042293D;
            // 
            // xrCheckBox8
            // 
            this.xrCheckBox8.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox8.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkNewHeadcount_4")});
            this.xrCheckBox8.LocationFloat = new DevExpress.Utils.PointFloat(11.1F, 0F);
            this.xrCheckBox8.Name = "xrCheckBox8";
            this.xrCheckBox8.SizeF = new System.Drawing.SizeF(83.81036F, 23F);
            this.xrCheckBox8.StylePriority.UseBorders = false;
            // 
            // xrTableCell77
            // 
            this.xrTableCell77.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell77.Borders = DevExpress.XtraPrinting.BorderSide.Right;
            this.xrTableCell77.Name = "xrTableCell77";
            this.xrTableCell77.StylePriority.UseBorderColor = false;
            this.xrTableCell77.StylePriority.UseBorders = false;
            this.xrTableCell77.Weight = 1.0808584653863784D;
            // 
            // xrTableRow11
            // 
            this.xrTableRow11.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell78,
            this.xrTableCell80,
            this.xrTableCell83});
            this.xrTableRow11.Name = "xrTableRow11";
            this.xrTableRow11.Weight = 0.9631510660085445D;
            // 
            // xrTableCell78
            // 
            this.xrTableCell78.Name = "xrTableCell78";
            this.xrTableCell78.Text = "xrTableCell64";
            this.xrTableCell78.Weight = 0.6986182798067444D;
            // 
            // xrTableCell80
            // 
            this.xrTableCell80.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell80.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox3});
            this.xrTableCell80.Name = "xrTableCell80";
            this.xrTableCell80.StylePriority.UseBorders = false;
            this.xrTableCell80.Weight = 2.563400976208015D;
            // 
            // xrCheckBox3
            // 
            this.xrCheckBox3.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox3.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkIn_Budget")});
            this.xrCheckBox3.LocationFloat = new DevExpress.Utils.PointFloat(36.56F, 2F);
            this.xrCheckBox3.Name = "xrCheckBox3";
            this.xrCheckBox3.SizeF = new System.Drawing.SizeF(298.4F, 22F);
            this.xrCheckBox3.StylePriority.UseBorders = false;
            this.xrCheckBox3.Text = " In budget / Trong ngân sách";
            // 
            // xrTableCell83
            // 
            this.xrTableCell83.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell83.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Right) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell83.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox4});
            this.xrTableCell83.Name = "xrTableCell83";
            this.xrTableCell83.StylePriority.UseBorderColor = false;
            this.xrTableCell83.StylePriority.UseBorders = false;
            this.xrTableCell83.Weight = 2.73798074398524D;
            // 
            // xrCheckBox4
            // 
            this.xrCheckBox4.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox4.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkOut_Budget")});
            this.xrCheckBox4.LocationFloat = new DevExpress.Utils.PointFloat(15.92F, 2F);
            this.xrCheckBox4.Name = "xrCheckBox4";
            this.xrCheckBox4.SizeF = new System.Drawing.SizeF(291.45F, 22F);
            this.xrCheckBox4.StylePriority.UseBorders = false;
            this.xrCheckBox4.Text = " Not in budget / Ngoài ngân sách";
            // 
            // xrTableRow18
            // 
            this.xrTableRow18.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell84,
            this.xrTableCell85,
            this.xrTableCell86,
            this.xrTableCell87,
            this.xrTableCell88,
            this.xrTableCell89});
            this.xrTableRow18.Name = "xrTableRow18";
            this.xrTableRow18.Weight = 1.5977672704570218D;
            // 
            // xrTableCell84
            // 
            this.xrTableCell84.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell84.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell84.Multiline = true;
            this.xrTableCell84.Name = "xrTableCell84";
            this.xrTableCell84.StylePriority.UseBorderColor = false;
            this.xrTableCell84.StylePriority.UseBorders = false;
            this.xrTableCell84.Text = "Replacement \r\nVị trí thay thế";
            this.xrTableCell84.Weight = 0.6986182798067444D;
            // 
            // xrTableCell85
            // 
            this.xrTableCell85.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell85.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrTableCell85.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox9});
            this.xrTableCell85.Name = "xrTableCell85";
            this.xrTableCell85.StylePriority.UseBorderColor = false;
            this.xrTableCell85.StylePriority.UseBorders = false;
            this.xrTableCell85.Weight = 0.91546581969407681D;
            // 
            // xrCheckBox9
            // 
            this.xrCheckBox9.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox9.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkReplacement_1")});
            this.xrCheckBox9.LocationFloat = new DevExpress.Utils.PointFloat(36.5569F, 3.570578F);
            this.xrCheckBox9.Name = "xrCheckBox9";
            this.xrCheckBox9.SizeF = new System.Drawing.SizeF(75.50517F, 23F);
            this.xrCheckBox9.StylePriority.UseBorders = false;
            // 
            // xrTableCell86
            // 
            this.xrTableCell86.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell86.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrTableCell86.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox10});
            this.xrTableCell86.Name = "xrTableCell86";
            this.xrTableCell86.StylePriority.UseBorderColor = false;
            this.xrTableCell86.StylePriority.UseBorders = false;
            this.xrTableCell86.Weight = 1.6479351565139389D;
            // 
            // xrCheckBox10
            // 
            this.xrCheckBox10.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox10.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkReplacement_2")});
            this.xrCheckBox10.LocationFloat = new DevExpress.Utils.PointFloat(74.23235F, 3.570557F);
            this.xrCheckBox10.Name = "xrCheckBox10";
            this.xrCheckBox10.SizeF = new System.Drawing.SizeF(100F, 23F);
            this.xrCheckBox10.StylePriority.UseBorders = false;
            // 
            // xrTableCell87
            // 
            this.xrTableCell87.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell87.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrTableCell87.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox11});
            this.xrTableCell87.Name = "xrTableCell87";
            this.xrTableCell87.StylePriority.UseBorderColor = false;
            this.xrTableCell87.StylePriority.UseBorders = false;
            this.xrTableCell87.Weight = 0.87029487076843881D;
            // 
            // xrCheckBox11
            // 
            this.xrCheckBox11.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox11.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkReplacement_3")});
            this.xrCheckBox11.LocationFloat = new DevExpress.Utils.PointFloat(15.9154F, 3.570557F);
            this.xrCheckBox11.Name = "xrCheckBox11";
            this.xrCheckBox11.SizeF = new System.Drawing.SizeF(100F, 23F);
            this.xrCheckBox11.StylePriority.UseBorders = false;
            // 
            // xrTableCell88
            // 
            this.xrTableCell88.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell88.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrTableCell88.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox12});
            this.xrTableCell88.Name = "xrTableCell88";
            this.xrTableCell88.StylePriority.UseBorderColor = false;
            this.xrTableCell88.StylePriority.UseBorders = false;
            this.xrTableCell88.Weight = 0.78682740783042293D;
            // 
            // xrCheckBox12
            // 
            this.xrCheckBox12.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox12.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkReplacement_4")});
            this.xrCheckBox12.LocationFloat = new DevExpress.Utils.PointFloat(11.09643F, 3.570578F);
            this.xrCheckBox12.Name = "xrCheckBox12";
            this.xrCheckBox12.SizeF = new System.Drawing.SizeF(83.8139F, 22.99998F);
            this.xrCheckBox12.StylePriority.UseBorders = false;
            // 
            // xrTableCell89
            // 
            this.xrTableCell89.BorderColor = System.Drawing.Color.DarkGray;
            this.xrTableCell89.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Right | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell89.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox13});
            this.xrTableCell89.Name = "xrTableCell89";
            this.xrTableCell89.StylePriority.UseBorderColor = false;
            this.xrTableCell89.StylePriority.UseBorders = false;
            this.xrTableCell89.Weight = 1.0808584653863784D;
            // 
            // xrCheckBox13
            // 
            this.xrCheckBox13.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox13.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkReplacement_5")});
            this.xrCheckBox13.LocationFloat = new DevExpress.Utils.PointFloat(31.22802F, 3.570557F);
            this.xrCheckBox13.Name = "xrCheckBox13";
            this.xrCheckBox13.SizeF = new System.Drawing.SizeF(100F, 23F);
            this.xrCheckBox13.StylePriority.UseBorders = false;
            // 
            // xrLabel4
            // 
            this.xrLabel4.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.xrLabel4.LocationFloat = new DevExpress.Utils.PointFloat(9.99999F, 0F);
            this.xrLabel4.Name = "xrLabel4";
            this.xrLabel4.Padding = new DevExpress.XtraPrinting.PaddingInfo(4, 4, 4, 4, 100F);
            this.xrLabel4.SizeF = new System.Drawing.SizeF(449.1666F, 27.73485F);
            this.xrLabel4.StylePriority.UseFont = false;
            this.xrLabel4.StylePriority.UsePadding = false;
            this.xrLabel4.Text = "Position information / Thông tin vị trí:";
            // 
            // RequestID
            // 
            this.RequestID.Description = "RequestID";
            this.RequestID.Name = "RequestID";
            // 
            // DetailReport2
            // 
            this.DetailReport2.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail3});
            this.DetailReport2.DataSource = this.sqlDataSource1;
            this.DetailReport2.Level = 2;
            this.DetailReport2.Name = "DetailReport2";
            // 
            // Detail3
            // 
            this.Detail3.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable4,
            this.xrLabel6});
            this.Detail3.HeightF = 67.57736F;
            this.Detail3.Name = "Detail3";
            // 
            // xrTable4
            // 
            this.xrTable4.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTable4.Font = new System.Drawing.Font("Times New Roman", 8.5F);
            this.xrTable4.LocationFloat = new DevExpress.Utils.PointFloat(10.0001F, 27.73482F);
            this.xrTable4.Name = "xrTable4";
            this.xrTable4.Padding = new DevExpress.XtraPrinting.PaddingInfo(5, 5, 5, 5, 100F);
            this.xrTable4.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow19});
            this.xrTable4.SizeF = new System.Drawing.SizeF(800F, 28F);
            this.xrTable4.StylePriority.UseBackColor = false;
            this.xrTable4.StylePriority.UseBorders = false;
            this.xrTable4.StylePriority.UseFont = false;
            this.xrTable4.StylePriority.UsePadding = false;
            // 
            // xrTableRow19
            // 
            this.xrTableRow19.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell90,
            this.xrTableCell91,
            this.xrTableCell95});
            this.xrTableRow19.Name = "xrTableRow19";
            this.xrTableRow19.Weight = 0.77578414101199866D;
            // 
            // xrTableCell90
            // 
            this.xrTableCell90.BorderColor = System.Drawing.Color.Gray;
            this.xrTableCell90.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell90.Name = "xrTableCell90";
            this.xrTableCell90.StylePriority.UseBorderColor = false;
            this.xrTableCell90.StylePriority.UseBorders = false;
            this.xrTableCell90.Text = "Employee / Nhân viên:";
            this.xrTableCell90.Weight = 1.1396649940076427D;
            // 
            // xrTableCell91
            // 
            this.xrTableCell91.BorderColor = System.Drawing.Color.Gray;
            this.xrTableCell91.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell91.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel18});
            this.xrTableCell91.Name = "xrTableCell91";
            this.xrTableCell91.StylePriority.UseBorderColor = false;
            this.xrTableCell91.StylePriority.UseBorders = false;
            this.xrTableCell91.Weight = 0.86033500599235746D;
            // 
            // xrLabel18
            // 
            this.xrLabel18.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel18.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.EmpID_Replace")});
            this.xrLabel18.LocationFloat = new DevExpress.Utils.PointFloat(9.99993F, 3.56422F);
            this.xrLabel18.Name = "xrLabel18";
            this.xrLabel18.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 2, 0, 100F);
            this.xrLabel18.SizeF = new System.Drawing.SizeF(104.7113F, 23F);
            this.xrLabel18.StylePriority.UseBorders = false;
            this.xrLabel18.StylePriority.UsePadding = false;
            // 
            // xrTableCell95
            // 
            this.xrTableCell95.BorderColor = System.Drawing.Color.Gray;
            this.xrTableCell95.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Right) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell95.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel17});
            this.xrTableCell95.Name = "xrTableCell95";
            this.xrTableCell95.StylePriority.UseBorderColor = false;
            this.xrTableCell95.StylePriority.UseBorders = false;
            this.xrTableCell95.Weight = 4D;
            // 
            // xrLabel17
            // 
            this.xrLabel17.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel17.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.EmpID_Replace_Name")});
            this.xrLabel17.LocationFloat = new DevExpress.Utils.PointFloat(16.66662F, 3.56422F);
            this.xrLabel17.Name = "xrLabel17";
            this.xrLabel17.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 2, 0, 100F);
            this.xrLabel17.SizeF = new System.Drawing.SizeF(503.7802F, 23F);
            this.xrLabel17.StylePriority.UseBorders = false;
            this.xrLabel17.StylePriority.UsePadding = false;
            // 
            // xrLabel6
            // 
            this.xrLabel6.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.xrLabel6.LocationFloat = new DevExpress.Utils.PointFloat(9.99999F, 0F);
            this.xrLabel6.Name = "xrLabel6";
            this.xrLabel6.Padding = new DevExpress.XtraPrinting.PaddingInfo(4, 4, 4, 4, 100F);
            this.xrLabel6.SizeF = new System.Drawing.SizeF(449.1666F, 27.73485F);
            this.xrLabel6.StylePriority.UseFont = false;
            this.xrLabel6.StylePriority.UsePadding = false;
            this.xrLabel6.Text = "Name of the person replaced / Tên nhân viên được thay thế:";
            // 
            // GroupHeader1
            // 
            this.GroupHeader1.GroupFields.AddRange(new DevExpress.XtraReports.UI.GroupField[] {
            new DevExpress.XtraReports.UI.GroupField("EmployeeID", DevExpress.XtraReports.UI.XRColumnSortOrder.Ascending)});
            this.GroupHeader1.HeightF = 26.04167F;
            this.GroupHeader1.Name = "GroupHeader1";
            this.GroupHeader1.Visible = false;
            // 
            // DetailReport3
            // 
            this.DetailReport3.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail4});
            this.DetailReport3.DataSource = this.sqlDataSource1;
            this.DetailReport3.Level = 3;
            this.DetailReport3.Name = "DetailReport3";
            // 
            // Detail4
            // 
            this.Detail4.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable5,
            this.xrLabel7});
            this.Detail4.HeightF = 75.66713F;
            this.Detail4.Name = "Detail4";
            this.Detail4.Visible = false;
            // 
            // xrTable5
            // 
            this.xrTable5.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTable5.Font = new System.Drawing.Font("Times New Roman", 8.5F);
            this.xrTable5.LocationFloat = new DevExpress.Utils.PointFloat(9.99999F, 27.73482F);
            this.xrTable5.Name = "xrTable5";
            this.xrTable5.Padding = new DevExpress.XtraPrinting.PaddingInfo(5, 5, 5, 5, 100F);
            this.xrTable5.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow32});
            this.xrTable5.SizeF = new System.Drawing.SizeF(800F, 37.93F);
            this.xrTable5.StylePriority.UseBackColor = false;
            this.xrTable5.StylePriority.UseBorders = false;
            this.xrTable5.StylePriority.UseFont = false;
            this.xrTable5.StylePriority.UsePadding = false;
            // 
            // xrTableRow32
            // 
            this.xrTableRow32.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell139,
            this.xrTableCell141,
            this.xrTableCell143});
            this.xrTableRow32.Name = "xrTableRow32";
            this.xrTableRow32.Weight = 1D;
            // 
            // xrTableCell139
            // 
            this.xrTableCell139.BorderColor = System.Drawing.Color.Gray;
            this.xrTableCell139.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell139.Name = "xrTableCell139";
            this.xrTableCell139.StylePriority.UseBorderColor = false;
            this.xrTableCell139.StylePriority.UseBorders = false;
            this.xrTableCell139.Text = "Starting date / Ngày bắt đầu làm việc:";
            this.xrTableCell139.Weight = 2D;
            // 
            // xrTableCell141
            // 
            this.xrTableCell141.BorderColor = System.Drawing.Color.Gray;
            this.xrTableCell141.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell141.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel5});
            this.xrTableCell141.Multiline = true;
            this.xrTableCell141.Name = "xrTableCell141";
            this.xrTableCell141.StylePriority.UseBorderColor = false;
            this.xrTableCell141.StylePriority.UseBorders = false;
            this.xrTableCell141.Weight = 2D;
            // 
            // xrLabel5
            // 
            this.xrLabel5.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel5.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.StartDate", "{0:dd/MM/yyyy}")});
            this.xrLabel5.LocationFloat = new DevExpress.Utils.PointFloat(29.16672F, 9.999996F);
            this.xrLabel5.Name = "xrLabel5";
            this.xrLabel5.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 2, 0, 100F);
            this.xrLabel5.SizeF = new System.Drawing.SizeF(183.58F, 22.99998F);
            this.xrLabel5.StylePriority.UseBorders = false;
            this.xrLabel5.StylePriority.UsePadding = false;
            this.xrLabel5.StylePriority.UseTextAlignment = false;
            this.xrLabel5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // xrTableCell143
            // 
            this.xrTableCell143.BorderColor = System.Drawing.Color.Gray;
            this.xrTableCell143.Borders = ((DevExpress.XtraPrinting.BorderSide)(((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Right) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell143.Name = "xrTableCell143";
            this.xrTableCell143.StylePriority.UseBorderColor = false;
            this.xrTableCell143.StylePriority.UseBorders = false;
            this.xrTableCell143.Weight = 2D;
            // 
            // xrLabel7
            // 
            this.xrLabel7.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.xrLabel7.LocationFloat = new DevExpress.Utils.PointFloat(9.99999F, 0F);
            this.xrLabel7.Name = "xrLabel7";
            this.xrLabel7.Padding = new DevExpress.XtraPrinting.PaddingInfo(4, 4, 4, 4, 100F);
            this.xrLabel7.SizeF = new System.Drawing.SizeF(449.1666F, 27.73485F);
            this.xrLabel7.StylePriority.UseFont = false;
            this.xrLabel7.StylePriority.UsePadding = false;
            this.xrLabel7.Text = "Starting date / Ngày bắt đầu làm việc:";
            // 
            // DetailReport4
            // 
            this.DetailReport4.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail5});
            this.DetailReport4.DataSource = this.sqlDataSource1;
            this.DetailReport4.Level = 4;
            this.DetailReport4.Name = "DetailReport4";
            // 
            // Detail5
            // 
            this.Detail5.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable6,
            this.xrLabel8});
            this.Detail5.HeightF = 116.9956F;
            this.Detail5.Name = "Detail5";
            // 
            // xrTable6
            // 
            this.xrTable6.BorderColor = System.Drawing.Color.Gray;
            this.xrTable6.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTable6.Font = new System.Drawing.Font("Times New Roman", 8.5F);
            this.xrTable6.LocationFloat = new DevExpress.Utils.PointFloat(10.00013F, 27.73488F);
            this.xrTable6.Name = "xrTable6";
            this.xrTable6.Padding = new DevExpress.XtraPrinting.PaddingInfo(5, 5, 5, 5, 100F);
            this.xrTable6.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow23,
            this.xrTableRow20,
            this.xrTableRow26});
            this.xrTable6.SizeF = new System.Drawing.SizeF(800F, 78F);
            this.xrTable6.StylePriority.UseBackColor = false;
            this.xrTable6.StylePriority.UseBorderColor = false;
            this.xrTable6.StylePriority.UseBorders = false;
            this.xrTable6.StylePriority.UseFont = false;
            this.xrTable6.StylePriority.UsePadding = false;
            // 
            // xrTableRow23
            // 
            this.xrTableRow23.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell115,
            this.xrTableCell117,
            this.xrTableCell119});
            this.xrTableRow23.Name = "xrTableRow23";
            this.xrTableRow23.Weight = 0.8431962296232296D;
            // 
            // xrTableCell115
            // 
            this.xrTableCell115.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell115.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox21});
            this.xrTableCell115.Name = "xrTableCell115";
            this.xrTableCell115.StylePriority.UseBorders = false;
            this.xrTableCell115.Weight = 2D;
            // 
            // xrCheckBox21
            // 
            this.xrCheckBox21.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox21.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkProbation_None")});
            this.xrCheckBox21.LocationFloat = new DevExpress.Utils.PointFloat(10F, 4.000002F);
            this.xrCheckBox21.Name = "xrCheckBox21";
            this.xrCheckBox21.SizeF = new System.Drawing.SizeF(138.2676F, 22F);
            this.xrCheckBox21.StylePriority.UseBorders = false;
            this.xrCheckBox21.Text = " None / Không";
            // 
            // xrTableCell117
            // 
            this.xrTableCell117.Borders = DevExpress.XtraPrinting.BorderSide.Top;
            this.xrTableCell117.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox22});
            this.xrTableCell117.Multiline = true;
            this.xrTableCell117.Name = "xrTableCell117";
            this.xrTableCell117.StylePriority.UseBorders = false;
            this.xrTableCell117.Weight = 2D;
            // 
            // xrCheckBox22
            // 
            this.xrCheckBox22.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox22.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkProbation_30")});
            this.xrCheckBox22.LocationFloat = new DevExpress.Utils.PointFloat(11.66673F, 4.000002F);
            this.xrCheckBox22.Name = "xrCheckBox22";
            this.xrCheckBox22.SizeF = new System.Drawing.SizeF(138.27F, 22F);
            this.xrCheckBox22.StylePriority.UseBorders = false;
            this.xrCheckBox22.Text = " 30 days / 30 ngày";
            // 
            // xrTableCell119
            // 
            this.xrTableCell119.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Right)));
            this.xrTableCell119.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrCheckBox23});
            this.xrTableCell119.Name = "xrTableCell119";
            this.xrTableCell119.StylePriority.UseBorders = false;
            this.xrTableCell119.Weight = 2D;
            // 
            // xrCheckBox23
            // 
            this.xrCheckBox23.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrCheckBox23.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("CheckState", null, "spRC_Print_PersonnelRequisition.chkProbation_60")});
            this.xrCheckBox23.LocationFloat = new DevExpress.Utils.PointFloat(9.999993F, 4.000002F);
            this.xrCheckBox23.Name = "xrCheckBox23";
            this.xrCheckBox23.SizeF = new System.Drawing.SizeF(138.27F, 22F);
            this.xrCheckBox23.StylePriority.UseBorders = false;
            this.xrCheckBox23.Text = " 60 days / 60 ngày";
            // 
            // xrTableRow20
            // 
            this.xrTableRow20.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell32,
            this.xrTableCell35,
            this.xrTableCell38});
            this.xrTableRow20.Name = "xrTableRow20";
            this.xrTableRow20.Weight = 0.84319622962322949D;
            // 
            // xrTableCell32
            // 
            this.xrTableCell32.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell32.Name = "xrTableCell32";
            this.xrTableCell32.StylePriority.UseBorders = false;
            this.xrTableCell32.Text = "Starting date / Ngày bắt đầu làm việc:";
            this.xrTableCell32.Weight = 2D;
            // 
            // xrTableCell35
            // 
            this.xrTableCell35.Borders = DevExpress.XtraPrinting.BorderSide.Top;
            this.xrTableCell35.Name = "xrTableCell35";
            this.xrTableCell35.StylePriority.UseBorders = false;
            this.xrTableCell35.Weight = 2D;
            // 
            // xrTableCell38
            // 
            this.xrTableCell38.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Right)));
            this.xrTableCell38.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel3});
            this.xrTableCell38.Name = "xrTableCell38";
            this.xrTableCell38.StylePriority.UseBorders = false;
            this.xrTableCell38.Text = "xrTableCell38";
            this.xrTableCell38.Weight = 2D;
            // 
            // xrLabel3
            // 
            this.xrLabel3.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel3.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.StartDate", "{0:dd/MM/yyyy}")});
            this.xrLabel3.LocationFloat = new DevExpress.Utils.PointFloat(11.64037F, 3.000032F);
            this.xrLabel3.Name = "xrLabel3";
            this.xrLabel3.Padding = new DevExpress.XtraPrinting.PaddingInfo(10, 2, 2, 0, 100F);
            this.xrLabel3.SizeF = new System.Drawing.SizeF(248.3596F, 22.99998F);
            this.xrLabel3.StylePriority.UseBorders = false;
            this.xrLabel3.StylePriority.UsePadding = false;
            this.xrLabel3.StylePriority.UseTextAlignment = false;
            this.xrLabel3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft;
            // 
            // xrTableRow26
            // 
            this.xrTableRow26.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell135,
            this.xrTableCell137});
            this.xrTableRow26.Name = "xrTableRow26";
            this.xrTableRow26.Weight = 0.84319622962322938D;
            // 
            // xrTableCell135
            // 
            this.xrTableCell135.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell135.Name = "xrTableCell135";
            this.xrTableCell135.StylePriority.UseBorders = false;
            this.xrTableCell135.Text = "Casual contract duration / Thời hạn hợp đồng cho nhân viên không thường xuyên:";
            this.xrTableCell135.Weight = 4D;
            // 
            // xrTableCell137
            // 
            this.xrTableCell137.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Right | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell137.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel10});
            this.xrTableCell137.Name = "xrTableCell137";
            this.xrTableCell137.StylePriority.UseBorders = false;
            this.xrTableCell137.Weight = 2D;
            // 
            // xrLabel10
            // 
            this.xrLabel10.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel10.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.ContractID")});
            this.xrLabel10.LocationFloat = new DevExpress.Utils.PointFloat(10.00003F, 1.907349E-06F);
            this.xrLabel10.Name = "xrLabel10";
            this.xrLabel10.Padding = new DevExpress.XtraPrinting.PaddingInfo(10, 2, 2, 0, 100F);
            this.xrLabel10.SizeF = new System.Drawing.SizeF(250F, 22.99999F);
            this.xrLabel10.StylePriority.UseBorders = false;
            this.xrLabel10.StylePriority.UsePadding = false;
            // 
            // xrLabel8
            // 
            this.xrLabel8.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.xrLabel8.LocationFloat = new DevExpress.Utils.PointFloat(9.99999F, 0F);
            this.xrLabel8.Name = "xrLabel8";
            this.xrLabel8.Padding = new DevExpress.XtraPrinting.PaddingInfo(4, 4, 4, 4, 100F);
            this.xrLabel8.SizeF = new System.Drawing.SizeF(449.1666F, 27.73485F);
            this.xrLabel8.StylePriority.UseFont = false;
            this.xrLabel8.StylePriority.UsePadding = false;
            this.xrLabel8.Text = "Probation period / Thời hạn thử việc:";
            // 
            // DetailReport5
            // 
            this.DetailReport5.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail6,
            this.DetailReport6});
            this.DetailReport5.DataSource = this.sqlDataSource1;
            this.DetailReport5.Level = 5;
            this.DetailReport5.Name = "DetailReport5";
            // 
            // Detail6
            // 
            this.Detail6.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTable3,
            this.xrLabel9});
            this.Detail6.HeightF = 194.2639F;
            this.Detail6.Name = "Detail6";
            // 
            // xrTable3
            // 
            this.xrTable3.BorderColor = System.Drawing.Color.Gray;
            this.xrTable3.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTable3.Font = new System.Drawing.Font("Times New Roman", 8.5F);
            this.xrTable3.LocationFloat = new DevExpress.Utils.PointFloat(10.00013F, 27.73488F);
            this.xrTable3.Name = "xrTable3";
            this.xrTable3.Padding = new DevExpress.XtraPrinting.PaddingInfo(5, 5, 5, 5, 100F);
            this.xrTable3.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow12,
            this.xrTableRow14,
            this.xrTableRow15,
            this.xrTableRow13,
            this.xrTableRow17,
            this.xrTableRow8});
            this.xrTable3.SizeF = new System.Drawing.SizeF(800F, 156F);
            this.xrTable3.StylePriority.UseBackColor = false;
            this.xrTable3.StylePriority.UseBorderColor = false;
            this.xrTable3.StylePriority.UseBorders = false;
            this.xrTable3.StylePriority.UseFont = false;
            this.xrTable3.StylePriority.UsePadding = false;
            // 
            // xrTableRow12
            // 
            this.xrTableRow12.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell19,
            this.xrTableCell33,
            this.xrTableCell37});
            this.xrTableRow12.Name = "xrTableRow12";
            this.xrTableRow12.Weight = 0.89603547255814586D;
            // 
            // xrTableCell19
            // 
            this.xrTableCell19.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top)));
            this.xrTableCell19.Name = "xrTableCell19";
            this.xrTableCell19.StylePriority.UseBorders = false;
            this.xrTableCell19.Weight = 2D;
            // 
            // xrTableCell33
            // 
            this.xrTableCell33.Borders = DevExpress.XtraPrinting.BorderSide.Top;
            this.xrTableCell33.Multiline = true;
            this.xrTableCell33.Name = "xrTableCell33";
            this.xrTableCell33.StylePriority.UseBorders = false;
            this.xrTableCell33.StylePriority.UseTextAlignment = false;
            this.xrTableCell33.Text = "On Probation / Trong thời gian thử việc";
            this.xrTableCell33.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            this.xrTableCell33.Weight = 2D;
            // 
            // xrTableCell37
            // 
            this.xrTableCell37.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Top | DevExpress.XtraPrinting.BorderSide.Right)));
            this.xrTableCell37.Name = "xrTableCell37";
            this.xrTableCell37.StylePriority.UseBorders = false;
            this.xrTableCell37.StylePriority.UseTextAlignment = false;
            this.xrTableCell37.Text = "After Probation / Sau thời gian thử việc";
            this.xrTableCell37.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            this.xrTableCell37.Weight = 2D;
            // 
            // xrTableRow14
            // 
            this.xrTableRow14.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell48,
            this.xrTableCell50,
            this.xrTableCell52});
            this.xrTableRow14.Name = "xrTableRow14";
            this.xrTableRow14.Weight = 0.89603547255814586D;
            // 
            // xrTableCell48
            // 
            this.xrTableCell48.Borders = DevExpress.XtraPrinting.BorderSide.Left;
            this.xrTableCell48.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.xrTableCell48.Name = "xrTableCell48";
            this.xrTableCell48.StylePriority.UseBorders = false;
            this.xrTableCell48.StylePriority.UseFont = false;
            this.xrTableCell48.Text = "Monthly Gross Salary / Lương Gộp hàng tháng";
            this.xrTableCell48.Weight = 2D;
            // 
            // xrTableCell50
            // 
            this.xrTableCell50.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel11});
            this.xrTableCell50.Name = "xrTableCell50";
            this.xrTableCell50.Weight = 2D;
            // 
            // xrLabel11
            // 
            this.xrLabel11.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel11.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Probation_Sal", "{0:#,#}")});
            this.xrLabel11.LocationFloat = new DevExpress.Utils.PointFloat(29.16659F, 1.919519F);
            this.xrLabel11.Name = "xrLabel11";
            this.xrLabel11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 8, 2, 0, 100F);
            this.xrLabel11.SizeF = new System.Drawing.SizeF(237.4999F, 22.99999F);
            this.xrLabel11.StylePriority.UseBorders = false;
            this.xrLabel11.StylePriority.UsePadding = false;
            this.xrLabel11.StylePriority.UseTextAlignment = false;
            this.xrLabel11.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // xrTableCell52
            // 
            this.xrTableCell52.Borders = DevExpress.XtraPrinting.BorderSide.Right;
            this.xrTableCell52.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel14});
            this.xrTableCell52.Name = "xrTableCell52";
            this.xrTableCell52.StylePriority.UseBorders = false;
            this.xrTableCell52.Weight = 2D;
            // 
            // xrLabel14
            // 
            this.xrLabel14.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel14.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Permanent_Sal", "{0:#,#}")});
            this.xrLabel14.LocationFloat = new DevExpress.Utils.PointFloat(18.33331F, 1.264662F);
            this.xrLabel14.Name = "xrLabel14";
            this.xrLabel14.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 8, 2, 0, 100F);
            this.xrLabel14.SizeF = new System.Drawing.SizeF(241.6666F, 22.99999F);
            this.xrLabel14.StylePriority.UseBorders = false;
            this.xrLabel14.StylePriority.UsePadding = false;
            this.xrLabel14.StylePriority.UseTextAlignment = false;
            this.xrLabel14.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // xrTableRow15
            // 
            this.xrTableRow15.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell54,
            this.xrTableCell56,
            this.xrTableCell58});
            this.xrTableRow15.Name = "xrTableRow15";
            this.xrTableRow15.Weight = 0.896035472558146D;
            // 
            // xrTableCell54
            // 
            this.xrTableCell54.Borders = DevExpress.XtraPrinting.BorderSide.Left;
            this.xrTableCell54.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.xrTableCell54.Name = "xrTableCell54";
            this.xrTableCell54.StylePriority.UseBorders = false;
            this.xrTableCell54.StylePriority.UseFont = false;
            this.xrTableCell54.Text = "Monthly Gross Transport support and field support fee / Hỗ trợ xăng xe & công tác" +
    " phí Gộp hàng tháng";
            this.xrTableCell54.Weight = 2D;
            // 
            // xrTableCell56
            // 
            this.xrTableCell56.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel12});
            this.xrTableCell56.Name = "xrTableCell56";
            this.xrTableCell56.Weight = 2D;
            // 
            // xrLabel12
            // 
            this.xrLabel12.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel12.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Probation_Travel", "{0:#,#}")});
            this.xrLabel12.LocationFloat = new DevExpress.Utils.PointFloat(29.16659F, 3.000011F);
            this.xrLabel12.Name = "xrLabel12";
            this.xrLabel12.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 8, 2, 0, 100F);
            this.xrLabel12.SizeF = new System.Drawing.SizeF(237.4999F, 22.99999F);
            this.xrLabel12.StylePriority.UseBorders = false;
            this.xrLabel12.StylePriority.UsePadding = false;
            this.xrLabel12.StylePriority.UseTextAlignment = false;
            this.xrLabel12.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // xrTableCell58
            // 
            this.xrTableCell58.Borders = DevExpress.XtraPrinting.BorderSide.Right;
            this.xrTableCell58.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel15});
            this.xrTableCell58.Name = "xrTableCell58";
            this.xrTableCell58.StylePriority.UseBorders = false;
            this.xrTableCell58.Weight = 2D;
            // 
            // xrLabel15
            // 
            this.xrLabel15.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel15.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Permanent_Travel", "{0:#,#}")});
            this.xrLabel15.LocationFloat = new DevExpress.Utils.PointFloat(18.33331F, 3.000011F);
            this.xrLabel15.Name = "xrLabel15";
            this.xrLabel15.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 8, 2, 0, 100F);
            this.xrLabel15.SizeF = new System.Drawing.SizeF(241.6666F, 22.99999F);
            this.xrLabel15.StylePriority.UseBorders = false;
            this.xrLabel15.StylePriority.UsePadding = false;
            this.xrLabel15.StylePriority.UseTextAlignment = false;
            this.xrLabel15.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // xrTableRow13
            // 
            this.xrTableRow13.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell2,
            this.xrTableCell6,
            this.xrTableCell11});
            this.xrTableRow13.Name = "xrTableRow13";
            this.xrTableRow13.Weight = 0.896035472558146D;
            // 
            // xrTableCell2
            // 
            this.xrTableCell2.Borders = DevExpress.XtraPrinting.BorderSide.Left;
            this.xrTableCell2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.xrTableCell2.Name = "xrTableCell2";
            this.xrTableCell2.StylePriority.UseBorders = false;
            this.xrTableCell2.StylePriority.UseFont = false;
            this.xrTableCell2.Text = "Monthly Gross other support fee / Hỗ trợ Gộp khác hàng tháng";
            this.xrTableCell2.Weight = 2D;
            // 
            // xrTableCell6
            // 
            this.xrTableCell6.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell6.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel13});
            this.xrTableCell6.Name = "xrTableCell6";
            this.xrTableCell6.StylePriority.UseBorders = false;
            this.xrTableCell6.Text = "xrTableCell6";
            this.xrTableCell6.Weight = 2D;
            // 
            // xrLabel13
            // 
            this.xrLabel13.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel13.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Probation_Allowance", "{0:#,#}")});
            this.xrLabel13.LocationFloat = new DevExpress.Utils.PointFloat(29.1666F, 1.91946F);
            this.xrLabel13.Name = "xrLabel13";
            this.xrLabel13.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 8, 2, 0, 100F);
            this.xrLabel13.SizeF = new System.Drawing.SizeF(237.4999F, 22.99999F);
            this.xrLabel13.StylePriority.UseBorders = false;
            this.xrLabel13.StylePriority.UsePadding = false;
            this.xrLabel13.StylePriority.UseTextAlignment = false;
            this.xrLabel13.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // xrTableCell11
            // 
            this.xrTableCell11.Borders = DevExpress.XtraPrinting.BorderSide.Right;
            this.xrTableCell11.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel16});
            this.xrTableCell11.Name = "xrTableCell11";
            this.xrTableCell11.StylePriority.UseBorders = false;
            this.xrTableCell11.Text = "xrTableCell11";
            this.xrTableCell11.Weight = 2D;
            // 
            // xrLabel16
            // 
            this.xrLabel16.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel16.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Permanent_Allowance", "{0:#,#}")});
            this.xrLabel16.LocationFloat = new DevExpress.Utils.PointFloat(18.33318F, 1.91946F);
            this.xrLabel16.Name = "xrLabel16";
            this.xrLabel16.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 8, 2, 0, 100F);
            this.xrLabel16.SizeF = new System.Drawing.SizeF(241.6666F, 22.99999F);
            this.xrLabel16.StylePriority.UseBorders = false;
            this.xrLabel16.StylePriority.UsePadding = false;
            this.xrLabel16.StylePriority.UseTextAlignment = false;
            this.xrLabel16.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // xrTableRow17
            // 
            this.xrTableRow17.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell23,
            this.xrTableCell28,
            this.xrTableCell29});
            this.xrTableRow17.Name = "xrTableRow17";
            this.xrTableRow17.Weight = 0.896035472558146D;
            // 
            // xrTableCell23
            // 
            this.xrTableCell23.Borders = DevExpress.XtraPrinting.BorderSide.Left;
            this.xrTableCell23.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.xrTableCell23.Name = "xrTableCell23";
            this.xrTableCell23.StylePriority.UseBorders = false;
            this.xrTableCell23.StylePriority.UseFont = false;
            this.xrTableCell23.Weight = 2D;
            // 
            // xrTableCell28
            // 
            this.xrTableCell28.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell28.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel29});
            this.xrTableCell28.Name = "xrTableCell28";
            this.xrTableCell28.StylePriority.UseBorders = false;
            this.xrTableCell28.Text = "xrTableCell28";
            this.xrTableCell28.Weight = 2D;
            // 
            // xrLabel29
            // 
            this.xrLabel29.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel29.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Other_old", "{0:#,#}")});
            this.xrLabel29.LocationFloat = new DevExpress.Utils.PointFloat(29.1666F, 1.919492F);
            this.xrLabel29.Name = "xrLabel29";
            this.xrLabel29.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 8, 2, 0, 100F);
            this.xrLabel29.SizeF = new System.Drawing.SizeF(237.4999F, 22.99999F);
            this.xrLabel29.StylePriority.UseBorders = false;
            this.xrLabel29.StylePriority.UsePadding = false;
            this.xrLabel29.StylePriority.UseTextAlignment = false;
            this.xrLabel29.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // xrTableCell29
            // 
            this.xrTableCell29.Borders = DevExpress.XtraPrinting.BorderSide.Right;
            this.xrTableCell29.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel30});
            this.xrTableCell29.Name = "xrTableCell29";
            this.xrTableCell29.StylePriority.UseBorders = false;
            this.xrTableCell29.Text = "xrTableCell29";
            this.xrTableCell29.Weight = 2D;
            // 
            // xrLabel30
            // 
            this.xrLabel30.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel30.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Other_new", "{0:#,#}")});
            this.xrLabel30.LocationFloat = new DevExpress.Utils.PointFloat(18.3333F, 1.919498F);
            this.xrLabel30.Name = "xrLabel30";
            this.xrLabel30.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 8, 2, 0, 100F);
            this.xrLabel30.SizeF = new System.Drawing.SizeF(241.6666F, 22.99999F);
            this.xrLabel30.StylePriority.UseBorders = false;
            this.xrLabel30.StylePriority.UsePadding = false;
            this.xrLabel30.StylePriority.UseTextAlignment = false;
            this.xrLabel30.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // xrTableRow8
            // 
            this.xrTableRow8.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell5,
            this.xrTableCell8,
            this.xrTableCell14});
            this.xrTableRow8.Name = "xrTableRow8";
            this.xrTableRow8.Weight = 0.89603547255814608D;
            // 
            // xrTableCell5
            // 
            this.xrTableCell5.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell5.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.xrTableCell5.Name = "xrTableCell5";
            this.xrTableCell5.StylePriority.UseBorders = false;
            this.xrTableCell5.StylePriority.UseFont = false;
            this.xrTableCell5.Weight = 2D;
            // 
            // xrTableCell8
            // 
            this.xrTableCell8.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrTableCell8.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel31});
            this.xrTableCell8.Name = "xrTableCell8";
            this.xrTableCell8.StylePriority.UseBorders = false;
            this.xrTableCell8.Weight = 2D;
            // 
            // xrLabel31
            // 
            this.xrLabel31.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel31.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Other_oldValue", "{0:#,#}")});
            this.xrLabel31.LocationFloat = new DevExpress.Utils.PointFloat(29.16664F, 1.919428F);
            this.xrLabel31.Name = "xrLabel31";
            this.xrLabel31.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 8, 2, 0, 100F);
            this.xrLabel31.SizeF = new System.Drawing.SizeF(237.4999F, 22.99999F);
            this.xrLabel31.StylePriority.UseBorders = false;
            this.xrLabel31.StylePriority.UsePadding = false;
            this.xrLabel31.StylePriority.UseTextAlignment = false;
            this.xrLabel31.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // xrTableCell14
            // 
            this.xrTableCell14.Borders = ((DevExpress.XtraPrinting.BorderSide)((DevExpress.XtraPrinting.BorderSide.Right | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableCell14.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel32});
            this.xrTableCell14.Name = "xrTableCell14";
            this.xrTableCell14.StylePriority.UseBorders = false;
            this.xrTableCell14.Weight = 2D;
            // 
            // xrLabel32
            // 
            this.xrLabel32.Borders = DevExpress.XtraPrinting.BorderSide.Bottom;
            this.xrLabel32.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Other_newValue", "{0:#,#}")});
            this.xrLabel32.LocationFloat = new DevExpress.Utils.PointFloat(18.3333F, 1.919437F);
            this.xrLabel32.Name = "xrLabel32";
            this.xrLabel32.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 8, 2, 0, 100F);
            this.xrLabel32.SizeF = new System.Drawing.SizeF(241.6666F, 22.99999F);
            this.xrLabel32.StylePriority.UseBorders = false;
            this.xrLabel32.StylePriority.UsePadding = false;
            this.xrLabel32.StylePriority.UseTextAlignment = false;
            this.xrLabel32.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // xrLabel9
            // 
            this.xrLabel9.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
            this.xrLabel9.LocationFloat = new DevExpress.Utils.PointFloat(9.99999F, 0F);
            this.xrLabel9.Name = "xrLabel9";
            this.xrLabel9.Padding = new DevExpress.XtraPrinting.PaddingInfo(4, 4, 4, 4, 100F);
            this.xrLabel9.SizeF = new System.Drawing.SizeF(449.1666F, 27.73485F);
            this.xrLabel9.StylePriority.UseFont = false;
            this.xrLabel9.StylePriority.UsePadding = false;
            this.xrLabel9.Text = "Benefit information / Thông tin về phúc lợi:";
            // 
            // DetailReport6
            // 
            this.DetailReport6.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail7,
            this.DetailReport7});
            this.DetailReport6.Level = 0;
            this.DetailReport6.Name = "DetailReport6";
            // 
            // Detail7
            // 
            this.Detail7.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel28,
            this.xrLabel27});
            this.Detail7.HeightF = 59.74236F;
            this.Detail7.Name = "Detail7";
            // 
            // xrLabel28
            // 
            this.xrLabel28.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Final_Date")});
            this.xrLabel28.Font = new System.Drawing.Font("Times New Roman", 8.5F);
            this.xrLabel28.LocationFloat = new DevExpress.Utils.PointFloat(524.7371F, 23F);
            this.xrLabel28.Name = "xrLabel28";
            this.xrLabel28.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel28.SizeF = new System.Drawing.SizeF(278.5963F, 23F);
            this.xrLabel28.StylePriority.UseFont = false;
            this.xrLabel28.StylePriority.UseTextAlignment = false;
            this.xrLabel28.Text = "xrLabel28";
            this.xrLabel28.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // xrLabel27
            // 
            this.xrLabel27.DataBindings.AddRange(new DevExpress.XtraReports.UI.XRBinding[] {
            new DevExpress.XtraReports.UI.XRBinding("Text", null, "spRC_Print_PersonnelRequisition.Final_ApprovedOrReject")});
            this.xrLabel27.Font = new System.Drawing.Font("Times New Roman", 8.5F);
            this.xrLabel27.LocationFloat = new DevExpress.Utils.PointFloat(355.8333F, 0F);
            this.xrLabel27.Name = "xrLabel27";
            this.xrLabel27.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel27.SizeF = new System.Drawing.SizeF(447.5001F, 23F);
            this.xrLabel27.StylePriority.UseFont = false;
            this.xrLabel27.StylePriority.UseTextAlignment = false;
            this.xrLabel27.Text = "xrLabel27";
            this.xrLabel27.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopRight;
            // 
            // DetailReport7
            // 
            this.DetailReport7.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail8});
            this.DetailReport7.Level = 0;
            this.DetailReport7.Name = "DetailReport7";
            // 
            // Detail8
            // 
            this.Detail8.HeightF = 100F;
            this.Detail8.Name = "Detail8";
            this.Detail8.Visible = false;
            // 
            // chkGender_Male
            // 
            this.chkGender_Male.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkGender_Male.Expression = "Iif([SexID]==\'F\', false , true )";
            this.chkGender_Male.Name = "chkGender_Male";
            // 
            // chkGender_FeMale
            // 
            this.chkGender_FeMale.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkGender_FeMale.Expression = "Iif([SexID]==\'F\', true , false)";
            this.chkGender_FeMale.Name = "chkGender_FeMale";
            // 
            // chkPaygroup_ZPV
            // 
            this.chkPaygroup_ZPV.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkPaygroup_ZPV.Expression = "Iif([SectionID]=\'ZPV\' , true, false )";
            this.chkPaygroup_ZPV.Name = "chkPaygroup_ZPV";
            // 
            // chkPaygroup_ZPS
            // 
            this.chkPaygroup_ZPS.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkPaygroup_ZPS.Expression = "Iif([SectionID]=\'ZPS\' , true, false )";
            this.chkPaygroup_ZPS.Name = "chkPaygroup_ZPS";
            // 
            // chkPaygroup_SANG
            // 
            this.chkPaygroup_SANG.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkPaygroup_SANG.Expression = "Iif([SectionID]=\'Sang\' , true, false )";
            this.chkPaygroup_SANG.Name = "chkPaygroup_SANG";
            // 
            // chkPaygroup_Casual
            // 
            this.chkPaygroup_Casual.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkPaygroup_Casual.Expression = "Iif([SectionID]=\'Casual\' , true, false )";
            this.chkPaygroup_Casual.Name = "chkPaygroup_Casual";
            // 
            // chkPaygroup_Other
            // 
            this.chkPaygroup_Other.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkPaygroup_Other.Expression = resources.GetString("chkPaygroup_Other.Expression");
            this.chkPaygroup_Other.Name = "chkPaygroup_Other";
            // 
            // chkNewHeadcount_1
            // 
            this.chkNewHeadcount_1.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkNewHeadcount_1.Expression = "Iif([ReasonID]=\'New\', Iif([TypeID]=\'Full\',  true, false) ,false )";
            this.chkNewHeadcount_1.Name = "chkNewHeadcount_1";
            // 
            // chkNewHeadcount_2
            // 
            this.chkNewHeadcount_2.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkNewHeadcount_2.Expression = "Iif([ReasonID]==\'New\', Iif([TypeID]==\'Upgrade\',  true, false) ,false )";
            this.chkNewHeadcount_2.Name = "chkNewHeadcount_2";
            // 
            // chkNewHeadcount_3
            // 
            this.chkNewHeadcount_3.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkNewHeadcount_3.Expression = "Iif([ReasonID]=\'New\', Iif([TypeID]=\'Casual\',  true, false) ,false )";
            this.chkNewHeadcount_3.Name = "chkNewHeadcount_3";
            // 
            // chkNewHeadcount_4
            // 
            this.chkNewHeadcount_4.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkNewHeadcount_4.Expression = "Iif([ReasonID]=\'New\', Iif([TypeID]=\'Part\',  true, false) ,false )";
            this.chkNewHeadcount_4.Name = "chkNewHeadcount_4";
            // 
            // chkReplacement_1
            // 
            this.chkReplacement_1.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkReplacement_1.Expression = "Iif([ReasonID]=\'Replace\', Iif([TypeID]=\'Full\',  true, false) ,false )";
            this.chkReplacement_1.Name = "chkReplacement_1";
            // 
            // chkReplacement_2
            // 
            this.chkReplacement_2.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkReplacement_2.Expression = "Iif([ReasonID]=\'Replace\', Iif([TypeID]=\'Upgrade\',  true, false) ,false )";
            this.chkReplacement_2.Name = "chkReplacement_2";
            // 
            // chkReplacement_3
            // 
            this.chkReplacement_3.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkReplacement_3.Expression = "Iif([ReasonID]=\'Replace\', Iif([TypeID]=\'Casual\',  true, false) ,false )";
            this.chkReplacement_3.Name = "chkReplacement_3";
            // 
            // chkReplacement_4
            // 
            this.chkReplacement_4.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkReplacement_4.Expression = "Iif([ReasonID]=\'Replace\', Iif([TypeID]=\'Part\',  true, false) ,false )";
            this.chkReplacement_4.Name = "chkReplacement_4";
            // 
            // chkReplacement_5
            // 
            this.chkReplacement_5.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkReplacement_5.Expression = "Iif([ReasonID]=\'Replace\', Iif([TypeID]=\'Maternity\',  true, false) ,false )";
            this.chkReplacement_5.Name = "chkReplacement_5";
            // 
            // chkWorking
            // 
            this.chkWorking.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkWorking.Name = "chkWorking";
            // 
            // chkResigned
            // 
            this.chkResigned.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkResigned.Name = "chkResigned";
            // 
            // chkProbation_None
            // 
            this.chkProbation_None.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkProbation_None.Expression = "Iif([ProbationID]=\'\', true ,false )";
            this.chkProbation_None.Name = "chkProbation_None";
            // 
            // chkProbation_30
            // 
            this.chkProbation_30.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkProbation_30.Expression = "Iif([ProbationID]=\'01\', true ,false )";
            this.chkProbation_30.Name = "chkProbation_30";
            // 
            // chkProbation_60
            // 
            this.chkProbation_60.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkProbation_60.Expression = "Iif([ProbationID]=\'08\', true ,false )";
            this.chkProbation_60.Name = "chkProbation_60";
            // 
            // chkPaygroup_OtherName
            // 
            this.chkPaygroup_OtherName.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkPaygroup_OtherName.Expression = "Iif([chkPaygroup_Other], [SectionName],\'\')";
            this.chkPaygroup_OtherName.Name = "chkPaygroup_OtherName";
            // 
            // chkIn_Budget
            // 
            this.chkIn_Budget.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkIn_Budget.Expression = "Iif([ReasonID]=\'New\', Iif([IsBudgetHead]==True, true, false), false)";
            this.chkIn_Budget.Name = "chkIn_Budget";
            // 
            // chkOut_Budget
            // 
            this.chkOut_Budget.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkOut_Budget.Expression = "Iif([ReasonID]=\'New\', Iif([IsBudgetHead]==True, false, true), false)";
            this.chkOut_Budget.Name = "chkOut_Budget";
            // 
            // chkPaygroup_PHYTO
            // 
            this.chkPaygroup_PHYTO.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkPaygroup_PHYTO.Expression = "Iif([SectionID]=\'Phyto\' , true, false )";
            this.chkPaygroup_PHYTO.Name = "chkPaygroup_PHYTO";
            // 
            // chkPaygroup_METRO
            // 
            this.chkPaygroup_METRO.DataMember = "spRC_Print_PersonnelRequisition";
            this.chkPaygroup_METRO.Expression = "Iif([SectionID]=\'Metro\' , true, false )";
            this.chkPaygroup_METRO.Name = "chkPaygroup_METRO";
            // 
            // Xtra_PersonnelRequisition_Full
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.Detail,
            this.TopMargin,
            this.BottomMargin,
            this.DetailReport,
            this.DetailReport1,
            this.DetailReport2,
            this.GroupHeader1,
            this.DetailReport3,
            this.DetailReport4,
            this.DetailReport5});
            this.CalculatedFields.AddRange(new DevExpress.XtraReports.UI.CalculatedField[] {
            this.chkGender_Male,
            this.chkGender_FeMale,
            this.chkPaygroup_ZPV,
            this.chkPaygroup_ZPS,
            this.chkPaygroup_SANG,
            this.chkPaygroup_Casual,
            this.chkPaygroup_Other,
            this.chkNewHeadcount_1,
            this.chkNewHeadcount_2,
            this.chkNewHeadcount_3,
            this.chkNewHeadcount_4,
            this.chkReplacement_1,
            this.chkReplacement_2,
            this.chkReplacement_3,
            this.chkReplacement_4,
            this.chkReplacement_5,
            this.chkWorking,
            this.chkResigned,
            this.chkProbation_None,
            this.chkProbation_30,
            this.chkProbation_60,
            this.chkPaygroup_OtherName,
            this.chkIn_Budget,
            this.chkOut_Budget,
            this.chkPaygroup_PHYTO,
            this.chkPaygroup_METRO});
            this.ComponentStorage.AddRange(new System.ComponentModel.IComponent[] {
            this.sqlDataSource1});
            this.DataMember = "spRC_Print_PersonnelRequisition";
            this.DataSource = this.sqlDataSource1;
            this.FormattingRuleSheet.AddRange(new DevExpress.XtraReports.UI.FormattingRule[] {
            this.formattingRule1,
            this.formattingRule2});
            this.Margins = new System.Drawing.Printing.Margins(0, 0, 50, 50);
            this.PageHeight = 1169;
            this.PageWidth = 1050;
            this.PaperKind = System.Drawing.Printing.PaperKind.Custom;
            this.Parameters.AddRange(new DevExpress.XtraReports.Parameters.Parameter[] {
            this.RequestID});
            this.Version = "15.2";
            ((System.ComponentModel.ISupportInitialize)(this.xrTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTable3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.TopMarginBand TopMargin;
        private DevExpress.XtraReports.UI.BottomMarginBand BottomMargin;
        private DevExpress.XtraReports.UI.XRLabel xrLabel1;
        public DevExpress.XtraReports.UI.XRPictureBox xrPictureBox1;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport;
        private DevExpress.XtraReports.UI.DetailBand Detail1;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport1;
        private DevExpress.XtraReports.UI.DetailBand Detail2;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport2;
        private DevExpress.XtraReports.UI.DetailBand Detail3;
        private DevExpress.XtraReports.UI.GroupHeaderBand GroupHeader1;
        private DevExpress.XtraReports.Parameters.Parameter RequestID;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport3;
        private DevExpress.XtraReports.UI.DetailBand Detail4;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport4;
        private DevExpress.XtraReports.UI.DetailBand Detail5;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport5;
        private DevExpress.XtraReports.UI.DetailBand Detail6;
        private DevExpress.XtraReports.UI.XRLabel xrLabel2;
        private DevExpress.XtraReports.UI.XRTable xrTable1;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow1;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell1;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell3;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell4;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow2;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell7;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell10;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell12;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow3;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell13;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell15;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell17;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell20;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow4;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell21;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell22;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell25;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow5;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell27;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell30;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell31;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell34;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow6;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell36;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell40;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell42;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell62;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow7;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell65;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell66;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell69;
        private DevExpress.DataAccess.Sql.SqlDataSource sqlDataSource1;
        private DevExpress.XtraReports.UI.XRLabel xrLabel4;
        private DevExpress.XtraReports.UI.XRLabel xrLabel6;
        private DevExpress.XtraReports.UI.XRTable xrTable5;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow32;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell141;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell143;
        private DevExpress.XtraReports.UI.XRLabel xrLabel7;
        private DevExpress.XtraReports.UI.XRLabel xrLabel8;
        private DevExpress.XtraReports.UI.XRLabel xrLabel9;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport6;
        private DevExpress.XtraReports.UI.DetailBand Detail7;
        private DevExpress.XtraReports.UI.DetailReportBand DetailReport7;
        private DevExpress.XtraReports.UI.DetailBand Detail8;
        private DevExpress.XtraReports.UI.XRTable xrTable2;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow9;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell18;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell24;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell71;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow16;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell59;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell60;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell61;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell156;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell157;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell158;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow10;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell72;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell73;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell74;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell75;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell76;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell77;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow11;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell78;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell80;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell83;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow18;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell84;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell85;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell86;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell87;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell88;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell89;
        private DevExpress.XtraReports.UI.XRTable xrTable4;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow19;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell90;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell91;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell95;
        private DevExpress.XtraReports.UI.XRTable xrTable6;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow23;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell115;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell117;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell119;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow26;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell135;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell137;
        private DevExpress.XtraReports.UI.XRTable xrTable3;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow12;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell19;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell33;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell37;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow14;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell48;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell50;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell52;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow15;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell54;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell56;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell58;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell139;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow8;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell5;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell8;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell14;
        private DevExpress.XtraReports.UI.FormattingRule formattingRule2;
        private DevExpress.XtraReports.UI.FormattingRule formattingRule1;
        private DevExpress.XtraReports.UI.CalculatedField chkGender_Male;
        private DevExpress.XtraReports.UI.CalculatedField chkGender_FeMale;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox3;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox5;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox6;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox7;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox8;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox4;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox9;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox10;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox11;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox12;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox13;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox21;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox22;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox23;
        private DevExpress.XtraReports.UI.XRLabel xrLabel5;
        private DevExpress.XtraReports.UI.XRLabel xrLabel10;
        private DevExpress.XtraReports.UI.XRLabel xrLabel11;
        private DevExpress.XtraReports.UI.XRLabel xrLabel14;
        private DevExpress.XtraReports.UI.XRLabel xrLabel12;
        private DevExpress.XtraReports.UI.XRLabel xrLabel15;
        private DevExpress.XtraReports.UI.XRLabel xrLabel13;
        private DevExpress.XtraReports.UI.XRLabel xrLabel16;
        private DevExpress.XtraReports.UI.XRLabel xrLabel18;
        private DevExpress.XtraReports.UI.XRLabel xrLabel17;
        private DevExpress.XtraReports.UI.CalculatedField chkPaygroup_ZPV;
        private DevExpress.XtraReports.UI.CalculatedField chkPaygroup_ZPS;
        private DevExpress.XtraReports.UI.CalculatedField chkPaygroup_SANG;
        private DevExpress.XtraReports.UI.CalculatedField chkPaygroup_Casual;
        private DevExpress.XtraReports.UI.CalculatedField chkPaygroup_Other;
        private DevExpress.XtraReports.UI.CalculatedField chkNewHeadcount_1;
        private DevExpress.XtraReports.UI.CalculatedField chkNewHeadcount_2;
        private DevExpress.XtraReports.UI.CalculatedField chkNewHeadcount_3;
        private DevExpress.XtraReports.UI.CalculatedField chkNewHeadcount_4;
        private DevExpress.XtraReports.UI.CalculatedField chkReplacement_1;
        private DevExpress.XtraReports.UI.CalculatedField chkReplacement_2;
        private DevExpress.XtraReports.UI.CalculatedField chkReplacement_3;
        private DevExpress.XtraReports.UI.CalculatedField chkReplacement_4;
        private DevExpress.XtraReports.UI.CalculatedField chkReplacement_5;
        private DevExpress.XtraReports.UI.CalculatedField chkWorking;
        private DevExpress.XtraReports.UI.CalculatedField chkResigned;
        private DevExpress.XtraReports.UI.CalculatedField chkProbation_None;
        private DevExpress.XtraReports.UI.CalculatedField chkProbation_30;
        private DevExpress.XtraReports.UI.CalculatedField chkProbation_60;
        private DevExpress.XtraReports.UI.CalculatedField chkPaygroup_OtherName;
        private DevExpress.XtraReports.UI.CalculatedField chkIn_Budget;
        private DevExpress.XtraReports.UI.CalculatedField chkOut_Budget;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell9;
        private DevExpress.XtraReports.UI.XRLabel xrLabel28;
        private DevExpress.XtraReports.UI.XRLabel xrLabel27;
        private DevExpress.XtraReports.UI.CalculatedField chkPaygroup_PHYTO;
        private DevExpress.XtraReports.UI.CalculatedField chkPaygroup_METRO;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell26;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell16;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow13;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell2;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell6;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell11;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow17;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell23;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell28;
        private DevExpress.XtraReports.UI.XRLabel xrLabel29;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell29;
        private DevExpress.XtraReports.UI.XRLabel xrLabel30;
        private DevExpress.XtraReports.UI.XRLabel xrLabel31;
        private DevExpress.XtraReports.UI.XRLabel xrLabel32;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow20;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell32;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell35;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell38;
        private DevExpress.XtraReports.UI.XRLabel xrLabel3;
        private DevExpress.XtraReports.UI.XRLabel xrLabel33;
        private DevExpress.XtraReports.UI.XRLabel xrLabel34;
        private DevExpress.XtraReports.UI.XRLabel xrLabel35;
        private DevExpress.XtraReports.UI.XRLabel xrLabel36;
        private DevExpress.XtraReports.UI.XRLabel xrLabel37;
        private DevExpress.XtraReports.UI.XRLabel xrLabel38;
        private DevExpress.XtraReports.UI.XRLabel xrLabel39;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox14;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox20;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox26;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox27;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox28;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox29;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell63;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox30;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox31;
        private DevExpress.XtraReports.UI.XRCheckBox xrCheckBox32;
        private DevExpress.XtraReports.UI.XRLabel xrLabel40;
    }
}
