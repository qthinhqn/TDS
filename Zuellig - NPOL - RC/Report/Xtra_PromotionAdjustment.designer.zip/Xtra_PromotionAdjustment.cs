﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace NPOL.Report
{
    public partial class Xtra_PromotionAdjustment : DevExpress.XtraReports.UI.XtraReport
    {
        public Xtra_PromotionAdjustment()
        {
            InitializeComponent();
        }

    }
}
