﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using NPOL.App_Code.Entities;
using NPOL.App_Code.Business;
using DevExpress.Web;
using System.Data;
using System.Collections;
using System.Collections.Specialized;

namespace NPOL.UserControl
{
    public partial class ucKPI_EmpCompetency : System.Web.UI.UserControl
    {
        bool IsValid = false;
        protected void Page_Load(object sender, EventArgs e)
        {
            //Session["PeriodID"] = 1;
            //Session["EmployeeID"] = "HR021";
            if(!IsPostBack)
            {
                Session.Remove("ParentID");
                Session.Remove("SubParentID");
            }
            grid.DataBind();
            grid.DetailRows.ExpandAllRows();
        }

        protected void detailGrid_DataSelect(object sender, EventArgs e)
        {
            Session["ParentID"] = (sender as ASPxGridView).GetMasterRowKeyValue();
        }

        protected void subDetailGrid_DataSelect(object sender, EventArgs e)
        {
            Session["SubParentID"] = (sender as ASPxGridView).GetMasterRowKeyValue();
        }

        protected void detailGrid_CustomUnboundColumnData(object sender, ASPxGridViewColumnDataEventArgs e)
        {
            //if (e.Column.FieldName == "Total")
            //{
            //    decimal price = (decimal)e.GetListSourceFieldValue("UnitPrice");
            //    int quantity = Convert.ToInt32(e.GetListSourceFieldValue("Quantity"));
            //    e.Value = price * quantity;
            //}
        }

        private void clearContent()
        {
            HiddenField1.Value = "";
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                //Validate
                if (IsValid == false)
                {
                    return;
                }
                else
                {
                    //
                    
                    clearContent();
                    grid.DataBind();

                    string message = "alert('Cập nhật dữ liệu thành công!')";
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "alert", message, true);
                }
            }
            catch (Exception ex)
            {
                string message = "alert('Cập nhật dữ liệu bị lỗi: " + ex.Message + "')";
                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "alert", message, true);
            }
        }

        protected void grid_CustomButtonCallback(object sender, DevExpress.Web.ASPxGridViewCustomButtonCallbackEventArgs e)
        {
            try
            {
                switch (e.ButtonID)
                {
                    // Edit item
                    case "Edit":
                        //HiddenField1.Value = grid.GetRowValues(e.VisibleIndex, "PosID").ToString();
                        //ASPxGridLookup1.Value = HiddenField1.Value;
                        
                        break;

                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
            }
        }
        protected void btRefresh_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(HiddenField1.Value))
            {
                clearContent();
            }
            else
            {
                // reload content
            }
        }

        protected void grid_CustomColumnDisplayText(object sender, DevExpress.Web.ASPxGridViewColumnDisplayTextEventArgs e)
        {
            // tuy chinh hien thi 
            object order = e.GetFieldValue("Order");
            object level = e.GetFieldValue("Level");

            if (e.Column.FieldName.Equals("Order"))
            {
                if (order != null)
                {
                    int i = (int)order;
                    if (level.ToString() == "1")
                    {
                        e.DisplayText = new NPOL.App_Code.Business.ToRomanNumber().ToRoman(i);
                    }
                    if (level.ToString() == "3")
                    {
                        e.DisplayText = i > 0 && i < 27 ? ((char)(i + 96)).ToString() + "." : null;
                    }
                }
            }

            object Description = e.GetFieldValue("Description");
            object Description_eng = e.GetFieldValue("Description_eng");
            if (e.Column.FieldName.Equals("Description"))
            {
                if (level != null && level.ToString() != "1")
                {
                    e.DisplayText = Description_eng + " / " + Description;
                }
            }
        }

        protected void grid_DetailRowGetButtonVisibility(object sender, ASPxGridViewDetailRowButtonEventArgs e)
        {
            
        }

        protected void grid_SubDetailRowGetButtonVisibility(object sender, ASPxGridViewDetailRowButtonEventArgs e)
        {
            
        }

        protected void ASPxGridView_DataBound(object sender, System.EventArgs e)
        {
            //((ASPxGridView)sender).DetailRows.ExpandAllRows();
            //((ASPxGridView)sender).SettingsDetail.ShowDetailButtons = false;
        }
        protected void Grid_BatchUpdate(object sender, DevExpress.Web.Data.ASPxDataBatchUpdateEventArgs e)
        {

            //foreach (var args in e.InsertValues)
            //    InsertNewItem(args.NewValues);
            foreach (var args in e.UpdateValues)
                UpdateItem(args.Keys, args.NewValues);
            //foreach (var args in e.DeleteValues)
            //    DeleteItem(args.Keys, args.Values);

            e.Handled = true;
            //Thoát chế độ edit
            grid.CancelEdit();
            //Cập nhật lại lưới
            grid.DataBind();
        }

        protected void gvDetail_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            UpdateItem(e.Keys, e.NewValues);
            //Hủy chức năng cập nhật tự động của SqlDatasource
            e.Cancel = true;
            //Thoát chế độ edit
            grid.CancelEdit();
            //Cập nhật lại lưới
            grid.DataBind();
        }

        protected void UpdateItem(OrderedDictionary keys, OrderedDictionary newValues)
        {
            //var id = Convert.ToInt32(keys["ID"]);
            //var item = GridData.First(i => i.ID == id);
            //LoadNewValues(item, newValues);
            //return item;
            try
            {
                int competency_id = Convert.ToInt32(keys["ID"]);
                float important = Convert.ToInt32(keys["Important"]);
                float point = Convert.ToInt32(keys["Point"]);
                int period = int.Parse(Session["PeriodID"].ToString());
                string EmployeeID = Session["EmployeeID"].ToString();

                EmpCompetency_DetailService thucthi = new EmpCompetency_DetailService();
                thucthi.UpdateScore(EmployeeID, period, competency_id, important, point);
            }
            catch (Exception ex)
            {
                string message = "alert('" + ex.Message + "')";
                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "alert", message, true);
            }
        }
    }
}